"""Write Shared Parameter Values"""

__title__ = "Write\nShared Parameter\nValues"
__author__= "J K Roshan\nKerketta"

####################################################################################################################
import time
start = time.time()
####################################################################################################################

from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import revit 
from pyrevit import script
from pyrevit import coreutils
from itertools import chain

# Select Excel File from Folder

logger = script.get_logger()
# if__name__ == '__main__':
source_file = forms.pick_file(file_ext='xlsx')
 
####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

####################################################################################################################
# Reading an excel file using Python 
import xlrd 
from xlrd import open_workbook 

# Give the location of the file 
loc = source_file
  
# To open Workbook 
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
 
   
####################################################################################################################
# Function to acquire all elements of category & get parameter value by name 

def all_elements_of_category(category):
	return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()

def get_parameter_value_by_name(element, parameterName):
	return element.LookupParameter(parameterName).AsValueString()


# Function for acquiring index of item in list

def indices(the_list, val):
    # """Always returns a list containing the indices of val in the_list"""
    retval = []
    last = 0
    while val in the_list[last:]:
             i = the_list[last:].index(val) 
             retval.append(last + i)
             last += i + 1   
    return retval

#####################################################################################################################
# Read Excel Parameters and Family Category

category_param_to_read = sheet.col_values(0)
print(category_param_to_read)

def str_parameters(_paraVal):
    	for x in _paraVal:
		return str(x)		

category_params = str_parameters(category_param_to_read)
print(category_params)

def str_convert(vals):
    val_collection = []
    for i in vals:
        if type(i) == 'float':
            temp =  [str(int(i)) for i in vals]
        elif type(i) == 'int':
            temp = [str(i) for i in vals]
        else:
            temp = [str(i) for i in vals]
        val_collection.append(temp)
    return(val_collection) 

# def str_convert(vals):
#     val_collection = []
#     for i in vals:
#         if type(i) == 'int':
#             val_collection =  [str(int(i)) for i in vals]
#         elif type(i) == 'str':
#             val_collection = [str(i) for i in vals]
#         else :
#             x = '-' 
#             val_collection.append(x)
#     return(val_collection) 


MXPA_ASSETNUM = sheet.col_values(0)

MXPA_ASSET_DESCRIPTION = sheet.col_values(1)
# MXPA_ASSET_DESCRIPTION = str_convert(MXPA_ASSET_DESCRIPTION)

MXPA_PARENT = sheet.col_values(2)
# MXPA_PARENT = str_convert(MXPA_PARENT)
# print(MXPA_PARENT)

MXPA_ASSET_STATUS = sheet.col_values(3)
# MXPA_ASSET_STATUS = str_convert(MXPA_ASSET_STATUS)
# print(MXPA_ASSET_STATUS)

MXPA_CLASSIFICATIONID = sheet.col_values(4)
# MXPA_CLASSIFICATIONID = str_convert(MXPA_CLASSIFICATIONID)

MXPA_FUNCTIONALLOCATION = sheet.col_values(5)
# MXPA_FUNCTIONALLOCATION = str_convert(MXPA_FUNCTIONALLOCATION)
 
MXPA_DESCRIPTION = sheet.col_values(6)
# MXPA_DESCRIPTION = str_convert(MXPA_DESCRIPTION)

MXPA_DAFACILITY = sheet.col_values(7)
# MXPA_DAFACILITY = str_convert(MXPA_DAFACILITY)

MXPA_CRITICALITY = sheet.col_values(8)
# MXPA_CRITICALITY = str_convert(MXPA_CRITICALITY)

MXPA_BUSINESSFACTOR = sheet.col_values(9)
MXPA_BUSINESSFACTOR = str_convert(MXPA_BUSINESSFACTOR)

MXPA_LOCATION_STATUS = sheet.col_values(10)
# MXPA_LOCATION_STATUS = str_convert(MXPA_LOCATION_STATUS)

MXPA_FUNCTIONAL = sheet.col_values(11)
MXPA_FUNCTIONAL = str_convert(MXPA_FUNCTIONAL)

MXPA_ITEMNUM = sheet.col_values(12)
# MXPA_ITEMNUM = str_convert(MXPA_ITEMNUM)

MXPA_SERIALNUM = sheet.col_values(13)
# MXPA_SERIALNUM = str_convert(MXPA_SERIALNUM)

MXPA_VENDOR = sheet.col_values(14)
# MXPA_VENDOR = str_convert(MXPA_VENDOR)

MXPA_MANUFACTURER = sheet.col_values(15)
# MXPA_MANUFACTURER = str_convert(MXPA_MANUFACTURER)

MXPA_MODEL = sheet.col_values(16)
# MXPA_MODEL = str_convert(MXPA_MODEL)

MXPA_PHY_LOCATION = sheet.col_values(17)
# MXPA_PHY_LOCATION = str_convert(MXPA_PHY_LOCATION)

MXPA_SYSTEMID = sheet.col_values(18)
# MXPA_SYSTEMID = str_convert(MXPA_SYSTEMID)

MXPA_SITEID = sheet.col_values(19)
# MXPA_SITEID = str_convert(MXPA_SITEID)
   
PA_ASSETPRESENCESTATUS = sheet.col_values(20)
PA_ASSETPRESENCESTATUS = str_convert(PA_ASSETPRESENCESTATUS)

PA_ASSETATTRIBUTESSTATUS = sheet.col_values(21)
PA_ASSETATTRIBUTESSTATUS = str_convert(PA_ASSETATTRIBUTESSTATUS)

PA_DANUMBERSTATUS = sheet.col_values(22)
PA_DANUMBERSTATUS = str_convert(PA_DANUMBERSTATUS)

PA_PHYSICALASSESSMENTSTATUS = sheet.col_values(23)
PA_PHYSICALASSESSMENTSTATUS = str_convert(PA_PHYSICALASSESSMENTSTATUS)

PA_3DMODELLATESTREVISIONSTATUS = sheet.col_values(24)
PA_3DMODELLATESTREVISIONSTATUS = str_convert(PA_3DMODELLATESTREVISIONSTATUS)

PA_ASSETREVISIONDATE = sheet.col_values(25)
# PA_ASSETREVISIONDATE = str_convert(PA_ASSETREVISIONDATE)

PA_WORKSINPROGRESS = sheet.col_values(26)
# PA_WORKSINPROGRESS = str_convert(PA_WORKSINPROGRESS)

asset_dictionary = {z[0]:list(z[1:]) for z in zip(MXPA_ASSETNUM, MXPA_ASSET_DESCRIPTION,MXPA_PARENT, MXPA_ASSET_STATUS, MXPA_CLASSIFICATIONID,\
                                                MXPA_FUNCTIONALLOCATION, MXPA_DESCRIPTION, MXPA_DAFACILITY, MXPA_CRITICALITY, MXPA_BUSINESSFACTOR,\
                                                MXPA_LOCATION_STATUS, MXPA_FUNCTIONAL, MXPA_ITEMNUM, MXPA_SERIALNUM, MXPA_VENDOR, MXPA_MANUFACTURER,\
                                                MXPA_MODEL, MXPA_PHY_LOCATION, MXPA_SYSTEMID, MXPA_SITEID,\
                                                PA_ASSETPRESENCESTATUS, PA_ASSETATTRIBUTESSTATUS, PA_DANUMBERSTATUS, PA_PHYSICALASSESSMENTSTATUS,\
                                                PA_3DMODELLATESTREVISIONSTATUS, PA_ASSETREVISIONDATE, PA_WORKSINPROGRESS)}
print(asset_dictionary)


####################################################################################################################
# All elements of category- UserInput

from rpw.ui.forms import SelectFromList
from rpw.utils.coerce import to_category 

userInputcategory = SelectFromList('Select Revit Category', ['Doors', 'Windows', 'Plumbing Fixtures'])
userInputcategory = str(userInputcategory)
selection_category = to_category(userInputcategory)
category_collector = all_elements_of_category(selection_category)
# print(category_collector)

####################################################################################################################
# Acquiring MXPA Asset Numbers for Category

def filtered_category_list(category_collector):
    cat_asset_num = list()
    for cat in category_collector:
        for param in cat.Parameters:
            if param.IsShared and param.Definition.Name == 'MXPA_ASSETNUM':
                paramValue = cat.get_Parameter(param.GUID)
                cat_asset_num.append(paramValue.AsString())
    
    cat_None_index = indices(cat_asset_num, None)
    filtered_cat_list = [ j for i, j in enumerate(category_collector) if i not in (cat_None_index)]
    return filtered_cat_list

def filtered_asset_num(filtered_assets):
    asset_num =  []
    for asset in filtered_assets:
        for param in asset.Parameters:
            if param.IsShared and param.Definition.Name == 'MXPA_ASSETNUM':
                paramValue = asset.get_Parameter(param.GUID)
                asset_num.append(paramValue.AsString())
    return asset_num          

####################################################################################################################

filtered_userSelected_category = filtered_category_list(category_collector)
filtered_userSelected_category_num = filtered_asset_num(filtered_userSelected_category)
# print(filtered_userSelected_category,filtered_userSelected_category_num)

#####################################################################################################################
# Acquiring MXPA Asset Classification List

classify = asset_dictionary.values()
print(classify)
count = len(classify)
classify_identity = [i[3] for i in classify[:count]]
# print(classify_identity)

####################################################################################################################

def classify_category_from_database(classificationID):
    classify_cat_index = indices(classify_identity,classificationID)
    classified_cat_keys = [ j for i, j in enumerate(asset_dictionary) if i in (classify_cat_index)]
    classified_cat_values = [ j for i, j in enumerate(classify) if i in (classify_cat_index)]
    return classified_cat_keys, classified_cat_values

#####################################################################################################################

userInputAssetCategoryfromDB = SelectFromList('Select Excel Classification', ['DOOR, ROLL UP', 'SHUTTER', 'TOILET', 'DOOR', 'ASSEMBLY'])
userInputAssetCategory = str(userInputAssetCategoryfromDB)
# print(userInputAssetCategory)
classified_userSelected_data  = classify_category_from_database(userInputAssetCategory)
# print(classified_userSelected_data)
classified_userSelected_keys = classified_userSelected_data[0]
classified_userSelected_values = classified_userSelected_data[1]
# print(classified_userSelected_keys,classified_userSelected_values)

####################################################################################################################

def scheduled_values_for_revit(asset_serial_number_index, filtered_asset_num_values = filtered_userSelected_category_num, classified_asset_keys = classified_userSelected_keys,\
                               classified_asset_values = classified_userSelected_values):
    temp = set(filtered_asset_num_values)
    lookup_assets = [i for i, val in enumerate(classified_asset_keys) if val in temp]
    res_list = [classified_asset_keys[i] for i in lookup_assets]
    values_from_register = [classified_asset_values[i] for i in lookup_assets]
    count = len(values_from_register)
    final_asset_data = [i[asset_serial_number_index] for i in values_from_register[:count]]
    index_test = range(len(res_list))
    test_dict = dict(zip(res_list,index_test))
    final_val = [test_dict.get(anum, None) for anum in filtered_asset_num_values]
    Revit_data = [final_asset_data[i] for i in final_val if i is not None]
    res_None = [i for i in range(len(final_val)) if final_val[i] != None]
    for(i, r) in zip(res_None, Revit_data):
        final_val[i] = r
    final_val = [str(i or '') for i in final_val]
    return final_val

###################################################################################################################

final_userSelected_Revit_values_asset_description = scheduled_values_for_revit(0)
final_userSelected_Revit_values_parent = scheduled_values_for_revit(1)
final_userSelected_Revit_values_asset_status = scheduled_values_for_revit(2)
final_userSelected_Revit_values_classificationID= scheduled_values_for_revit(3)
final_userSelected_Revit_values_functional_location = scheduled_values_for_revit(4)
final_userSelected_Revit_values_description = scheduled_values_for_revit(5)
final_userSelected_Revit_values_dafacility = scheduled_values_for_revit(6)
final_userSelected_Revit_values_criticality = scheduled_values_for_revit(7)
final_userSelected_Revit_values_businessfactor = scheduled_values_for_revit(8)
final_userSelected_Revit_values_location_status = scheduled_values_for_revit(9)
final_userSelected_Revit_values_functional = scheduled_values_for_revit(10)
final_userSelected_Revit_values_itemnum  = scheduled_values_for_revit(11)
final_userSelected_Revit_values_serialnum = scheduled_values_for_revit(12)
final_userSelected_Revit_values_vendor = scheduled_values_for_revit(13)
final_userSelected_Revit_values_manufacturer = scheduled_values_for_revit(14)
final_userSelected_Revit_values_model = scheduled_values_for_revit(15)
final_userSelected_Revit_values_phy_location = scheduled_values_for_revit(16)
final_userSelected_Revit_values_systemID = scheduled_values_for_revit(17)
final_userSelected_Revit_values_siteID = scheduled_values_for_revit(18)

final_userSelected_Revit_values_pa_asset_presence_status = scheduled_values_for_revit(19)
final_userSelected_Revit_values_pa_asset_attributes_status = scheduled_values_for_revit(20)
final_userSelected_Revit_values_da_number_status = scheduled_values_for_revit(21) 
final_userSelected_Revit_values_physical_assessment_status =  scheduled_values_for_revit(22)
final_userSelected_Revit_values_pa_3d_model_latest_revision_status =  scheduled_values_for_revit(23)
final_userSelected_Revit_values_pa_asset_revision_date =  scheduled_values_for_revit(24)
final_userSelected_Revit_values_pa_works_in_progress =  scheduled_values_for_revit(25)

# print(final_userSelected_Revit_values_pa_asset_presence_status)

temp = map(str, final_userSelected_Revit_values_pa_asset_presence_status)
for f in final_userSelected_Revit_values_pa_asset_presence_status:
    temp = type(f)
    
# print(temp)

#####################################################################################################################

def set_parameter_by_name(element, parameterName, value):
	element.LookupParameter(parameterName).Set(value)

def add_values_to_revit(asset_name, final_asset_values_for_Revit,  filtered_assets = filtered_userSelected_category):
    t = Transaction(doc, 'script')
    write_asset_pass = []
    write_asset_fail = []
    
    t.Start()
    for p in filtered_assets:
        try:
            write_asset_pass = [set_parameter_by_name(p, asset_name, pval) for p, pval in zip(filtered_assets, final_asset_values_for_Revit)]
        except:
            write_asset_fail.append(pval)

    t.Commit()
    return(write_asset_pass,write_asset_fail)

#####################################################################################################################

write_userSelected_values_asset_description_to_Revit = add_values_to_revit('MXPA_ASSET_DESCRIPTION', final_userSelected_Revit_values_asset_description)
write_userSelected_values_parent_to_Revit = add_values_to_revit('MXPA_PARENT', final_userSelected_Revit_values_parent)
write_userSelected_values_asset_status_to_Revit = add_values_to_revit('MXPA_ASSET_STATUS', final_userSelected_Revit_values_asset_status)
write_userSelected_values_classificationID_to_Revit = add_values_to_revit('MXPA_CLASSIFICATIONID', final_userSelected_Revit_values_classificationID)
write_userSelected_values_functional_location_to_Revit = add_values_to_revit('MXPA_FUNCTIONAL LOCATION', final_userSelected_Revit_values_functional_location)
write_userSelected_values_description_to_Revit = add_values_to_revit('MXPA_DESCRIPTION', final_userSelected_Revit_values_description)
write_userSelected_values_dafacility_to_Revit = add_values_to_revit('MXPA_DAFACILITY', final_userSelected_Revit_values_dafacility)
write_userSelected_values_criticality_to_Revit = add_values_to_revit('MXPA_CRITICALITY', final_userSelected_Revit_values_criticality)
write_userSelected_values_businessfactor_to_Revit = add_values_to_revit('MXPA_BUSINESSFACTOR', final_userSelected_Revit_values_businessfactor)
write_userSelected_values_location_status_to_Revit = add_values_to_revit('MXPA_LOCATION_STATUS', final_userSelected_Revit_values_location_status)
write_userSelected_values_functional_to_Revit = add_values_to_revit('MXPA_FUNCTIONAL', final_userSelected_Revit_values_functional)
write_userSelected_values_itemnum_to_Revit = add_values_to_revit('MXPA_ITEMNUM', final_userSelected_Revit_values_itemnum)
write_userSelected_values_serialnum_to_Revit = add_values_to_revit('MXPA_SERIALNUM', final_userSelected_Revit_values_serialnum)
write_userSelected_values_vendor_to_Revit = add_values_to_revit('MXPA_VENDOR', final_userSelected_Revit_values_vendor)
write_userSelected_values_manufacturer_to_Revit = add_values_to_revit('MXPA_MANUFACTURER', final_userSelected_Revit_values_manufacturer)
write_userSelected_values_model_to_Revit = add_values_to_revit('MXPA_MODEL', final_userSelected_Revit_values_model)
write_userSelected_values_phy_location_to_Revit = add_values_to_revit('MXPA_PHY_LOCATION', final_userSelected_Revit_values_phy_location)
write_userSelected_values_systemID_to_Revit = add_values_to_revit('MXPA_SYSTEMID', final_userSelected_Revit_values_systemID)
write_userSelected_values_siteID_to_Revit = add_values_to_revit('MXPA_SITEID', final_userSelected_Revit_values_siteID)

write_userSelected_Revit_values_pa_asset_presence_status = add_values_to_revit('PA_ASSET PRESENCE STATUS', final_userSelected_Revit_values_pa_asset_presence_status)
write_userSelected_Revit_values_pa_asset_attributes_status = add_values_to_revit('PA_ASSET ATTRIBUTES STATUS', final_userSelected_Revit_values_pa_asset_attributes_status)
write_userSelected_Revit_values_da_number_status = add_values_to_revit('PA_DA NUMBER STATUS', final_userSelected_Revit_values_da_number_status)
write_userSelected_Revit_values_physical_assessment_status = add_values_to_revit('PA_PHYSICAL ASSESSMENT STATUS', final_userSelected_Revit_values_physical_assessment_status )
write_userSelected_Revit_values_pa_3d_model_latest_revision_status = add_values_to_revit('PA_3D MODEL LATEST REVISION STATUS', final_userSelected_Revit_values_pa_3d_model_latest_revision_status)
write_userSelected_Revit_values_pa_asset_revision_date = add_values_to_revit('PA_ASSET REVISION DATE', final_userSelected_Revit_values_pa_asset_revision_date)
write_userSelected_Revit_values_pa_works_in_progress = add_values_to_revit('PA_WORKS IN PROGRESS', final_userSelected_Revit_values_pa_works_in_progress)

#####################################################################################################################

print ('It took', time.time()-start, 'seconds.')

print('*'*216)  

##################################################################################################################### 



# 
