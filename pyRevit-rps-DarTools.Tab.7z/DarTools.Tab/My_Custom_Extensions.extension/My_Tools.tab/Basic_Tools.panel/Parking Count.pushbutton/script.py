"""Read Parking Elements"""

__title__ = "Parking\nCount"
__author__= "roshan"

import os.path as os
import re
from math import sqrt, pi, sin, cos, degrees


# pylint: disable=E0401,W0703,C0103
from collections import namedtuple

from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from itertools import chain
from pyrevit import revit, UI, DB
from pyrevit.framework import List



from rpw.ui.forms import SelectFromList
from rpw.utils.coerce import to_category 


import clr
clr.AddReference("RevitAPI")
from Autodesk.Revit.DB import *
  
####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

#####################################################################################################################

def indices(the_list, val):
    # """Always returns a list containing the indices of val in the_list"""
    retval = []
    last = 0
    while val in the_list[last:]:
             i = the_list[last:].index(val) 
             retval.append(last + i)
             last += i + 1   
    return retval

#####################################################################################################################

# Function to acquire all elements of category & get parameter value by name 

def all_elements_of_category(category):
	return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()

def get_parameter_value_by_name(element, parameterName):
	return element.LookupParameter(parameterName).AsValueString()

#####################################################################################################################

# Creating fucntion for setting parameter by name

def set_parameter_by_name(element, parameterName, value):
	element.LookupParameter(parameterName).Set(value)
 
#####################################################################################################################

car_park_elems = list()
car_park_elems = all_elements_of_category(BuiltInCategory.OST_Parking)
# print(car_parks_elems)

levels_in_project = FilteredElementCollector(doc).OfClass(Level).WhereElementIsNotElementType().ToElements()
levels_in_project_name = [lvl.Name for lvl in levels_in_project]
# print(levels_in_project_name)

userInputLevel = SelectFromList('Select Parking Level', [l for l in levels_in_project_name])
userInputLevel = str(userInputLevel)



levels = all_elements_of_category(BuiltInCategory.OST_Levels)
user_selected_level_bool = [lvl.Name == userInputLevel for lvl in levels]
filtered_level_index = [ l for l, index in enumerate(user_selected_level_bool) if index]
filtered_level = [levels[i] for i in filtered_level_index]
lvlId = filtered_level[0].Id

filter = ElementLevelFilter(lvlId)
car_park_filtered_elems = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Parking).WherePasses(filter).WhereElementIsNotElementType().ToElements()



selection = revit.get_selection()

class MassSelectionFilter(UI.Selection.ISelectionFilter):
    # standard API override function
    def AllowElement(self, element):
        if not element.ViewSpecific:
            return True
        else:
            return False
    # standard API override function
    def AllowReference(self, refer, point):
        return False

try:
    msfilter = MassSelectionFilter()
    selection_list = revit.pick_rectangle(pick_filter=msfilter)

    user_selected_lines_bool = []
    filtered_lines_index = []
    filter_selected_lines = []
    
    for el in selection_list:
        
        user_selected_lines_bool = ['Model Lines' == lines.Name for lines in selection_list]
        filtered_lines_index = [ln for ln, index in enumerate(user_selected_lines_bool) if index]
        filter_selected_lines = [selection_list[i] for i in filtered_lines_index]
        
    selection.set_to(filter_selected_lines)
    revit.uidoc.RefreshActiveView()
except Exception:
    pass

# print(filter_selected_lines)


Curves_in_selection = [lines.GeometryCurve for lines in filter_selected_lines]
print(Curves_in_selection)

Curve_lengths = [lines.Location.Curve.Length for lines in filter_selected_lines]
print(Curve_lengths)

# startpoints = [curve.GetEndPoint(0) for curve in Curves_in_selection]
# endpoints = [curve.GetEndPoint(1) for curve in Curves_in_selection]

# print(startpoints)
# print(endpoints)    



      
#define a transaction variable and describe the transaction
t = Transaction(doc, 'This is my new transaction')

t.Start()
   
car_park_bb = [cp.get_BoundingBox(None) for cp in car_park_filtered_elems]  
print(car_park_bb)

# # Get max and min points of bounding box.
# car_park_bb_max = car_park_bb.Max
# car_park_bb_min = car_park_bb.Min

# # Get center point between max and min points of bounding box.
# car_park_bb_center = (car_park_bb_max + car_park_bb_min) / 2

# print(car_park_bb_center)     

# Close the transaction
t.Commit()
             
        
        
        
        
        
        
        





















    







        # def pickobject():
        #     from Autodesk.Revit.UI.Selection import ObjectType

        #     #define the active Revit application and document
        #     app = __revit__.Application
        #     doc = __revit__.ActiveUIDocument.Document
        #     uidoc = __revit__.ActiveUIDocument

        #     #define a transaction variable and describe the transaction
        #     t = Transaction(doc, 'This is my new transaction')

        #     # Begin new transaction
        #     t.Start()

        #     # Select an element in Revit
        #     picked = uidoc.Selection.PickObject(ObjectType.Element, "Select something.")


        #     ### ?????????? ###

        #     # Get bounding box of selected element.
        #     picked_bb = BoundingBoxXYZ(picked)  

        #     # Get max and min points of bounding box.
        #     picked_bb_max = picked_bb.Max
        #     picked_bb_min = picked_bb.Min

        #     # Get center point between max and min points of bounding box.
        #     picked_bb_center = (picked_bb_max + picked_bb_min) / 2

        #     ### ?????????? ###    

        #     # Close the transaction
        #     t.Commit()
        