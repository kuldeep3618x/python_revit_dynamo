"""Rename Worksets"""

"""Activates selection tool that picks a specific type of element.

Shift-Click:
Pick from all available categories.
"""
# pylint: disable=E0401,W0703,C0103
from collections import namedtuple




__title__ = "Rename\nWorksets"
__author__= "J K Roshan Kerketta"

import os.path as os
from pyrevit import script
from pyrevit import forms


import clr
clr.AddReference('ProtoGeometry')
from Autodesk.DesignScript.Geometry import *


# Import DocumentManager and TransactionManager

clr.AddReference("RevitServices")
import RevitServices
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

clr.AddReference("RevitAPI")
import Autodesk
from Autodesk.Revit.DB import *

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

####################################################################################################################

logger = script.get_logger()
# if__name__ == '__main__':
source_file = forms.pick_file(file_ext='xls')

####################################################################################################################

# Reading an excel file using Python 

import xlrd 
from xlrd import open_workbook 

# Give the location of the file 

loc = source_file
  
# To open Workbook 
wb = xlrd.open_workbook(loc) 

sheet = wb.sheet_by_index(0)    #ARCHITECTURE
# sheet = wb.sheet_by_index(1)      #SKIN
# sheet = wb.sheet_by_index(2)      #INTERIOR
# sheet = wb.sheet_by_index(3)    #SIGNAGE

####################################################################################################################


collector = FilteredWorksetCollector(doc)
worksets_in_current_doc = collector.OfKind(WorksetKind.UserWorkset).ToWorksets()
# print(worksets_in_current_doc)
workset_names_in_current_doc = [(workset.Name) for workset in worksets_in_current_doc]
# print(workset_names_in_current_doc)
file_workset_dict = dict(zip(workset_names_in_current_doc,worksets_in_current_doc))
# print(file_workset_dict)

#Workset Names in Excel file

workset_names = sheet.col_values(1)
workset_renames = sheet.col_values(2)

rename_dictionary = dict(zip(workset_names,workset_renames))

# print(workset_names,workset_renames,rename_dictionary)
####################################################################################################################

# Filtered Workset Names 

filtered_Worksets = [w for w in workset_names if w in workset_names_in_current_doc]
# print(filtered_Worksets)

filtered_Workset_renames = [rename_dictionary[x] for x in filtered_Worksets]
# print(filtered_Workset_renames)

filtered_Revit_Worksets = [file_workset_dict[x] for x in filtered_Worksets]
# print(filtered_Revit_Worksets)


####################################################################################################################


t = Transaction(doc)
t.Start('Rename Worksets')
# TransactionManager.Instance.EnsureInTransaction(doc)
for workset, name in zip(filtered_Revit_Worksets,filtered_Workset_renames):
    WorksetTable.RenameWorkset(doc,workset.Id,name)
# TransactionManager.Instance.TransactionTaskDone()

t.Commit()


