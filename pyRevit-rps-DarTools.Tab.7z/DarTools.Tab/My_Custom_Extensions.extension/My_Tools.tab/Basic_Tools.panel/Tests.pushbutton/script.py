# Door test


# __title__ = "DoorTest"
# __author__= "J K Roshan\nKerketta"

# from pyrevit.coreutils import envvars
# from decimal import *
# from pyrevit import forms
# from pyrevit import script
# from pyrevit import coreutils
# from pyrevit import HOST_APP
# from pyrevit import revit, DB
# from itertools import chain
# from itertools import islice

# from pyrevit import framework
# from pyrevit import revit, DB
# from pyrevit import script


# out = script.get_output()

####################################################################################################################

# def format_length(length_value, doc = None):
    # doc = doc or HOST_APP.doc
    # return DB.UnitFormatUtils.Format(units = doc.GetUnits(), unitType = DB.UnitType.UT_Length, value = length_value, maxAccuracy = False, forEditing =False)

####################################################################################################################

# import itertools
# import Autodesk.Revit.DB as DB
# from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
# from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

# doc = __revit__.ActiveUIDocument.Document
# uidoc = __revit__.ActiveUIDocument

####################################################################################################################
# Function to acquire all elements of category & get parameter value by name 

# def all_elements_of_category(category):
	# return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()


# doors = all_elements_of_category(BuiltInCategory.OST_Doors)
# print(doors)
# door_comments = [d.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).AsString() for d in doors]
# print(door_comments)

# exclusions = ["ROLLING SHUTTER", "ACCESS PANEL", "CLOSET DOOR", "Glass door" , "Curtain wall door", "Access Panel"]
# exclusions = [ "Glass door" , "Curtain wall door"]

# indices_for_glazed_doors = [i for i, x in enumerate(door_comments) if x not in exclusions]
# print(indices_for_non_glazed_doors)

################################################################################

# filtered_doors = [doors[i] for i in indices_for_glazed_doors]
# filtered_door_numbers = [d.get_Parameter(BuiltInParameter.DOOR_NUMBER).AsString() for d in filtered_doors]
# filtered_door_levels = []

# for item in filtered_doors:
#     if item != None:
#     # filtered_door_levels.append(item.Document.GetElement(item.LevelId).ToDSType(True))
#         filtered_door_levels.append(item.Document.GetElement(item.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM).AsElementId()).ToDSType(True))
#     else:
#         filtered_door_levels.append('None')

# elementlist = []    
    
# for item in filtered_doors:
#     try:	
# 		elementlist.append(item.Document.GetElement(item.LevelId).ToDSType(True))
# 	except:
# 		try:
# 			elementlist.append(item.Level.ToDSType(True))
# 		except:
# 			try:
# 				elementlist.append(item.GenLevel.ToDSType(True))
# 			except:
# 				try:
# 					elementlist.append(item.Document.GetElement(item.get_Parameter(BuiltInParameter.INSTANCE_REFERENCE_LEVEL_PARAM).AsElementId()).ToDSType(True))
# 				except:
# 					elementlist.append(list())

# print(elementlist)

# def all_elements_with_type_parameter_AsDouble(sample_doors, door_family_type_parameter):
#     door_family_test = []
#     door_family_param = []
    
#     for d in sample_doors:
#         door_type = d.Symbol
#         door_family_param = door_type.LookupParameter(door_family_type_parameter)
#         temp = []
#         if door_family_param:
#             temp = door_family_param.AsDouble()
#             door_family_test.append(temp)
#         else:
#             temp = 'fail'
#             door_family_test.append(temp)
#     return door_family_test


# test_for_door_dimensions = all_elements_with_type_parameter_AsDouble(filtered_doors, 'Width')
# # print(test_for_door_dimensions)
# # print(filtered_doors)

# door_Selections = [out.linkify(door.Id) for door in filtered_doors]
# door_output = [('{} - {}'). format(f,d) for d,f in zip(door_Selections,filtered_door_numbers)]
# for d in door_output:
#     print(d)
    

# from pyrevit import script

# output = script.get_output()

# output.print_md('Hello World')
# test =output.print_md('**Hello world**')
# print('hello world')
# output.add_style('body{color: blue; }')

# # output.add_style('test{color: blue; }')


# print('hello world')
# 

# from pyrevit import forms
# layout = '<Window ShowInTaskbar="False" ResizeMode="NoResize" ' \
#          'WindowStartupLocation="CenterScreen" ' \
#          'HorizontalContentAlignment="Center">' \
#          '</Window>'
# w = forms.WPFWindow(layout, literal_string=True)
# w.show()

# print('Hello pyRevit user')

# a = 'hello'

# def print_x(sample_text):
#     out.print_md('**{} have fun**'.format(sample_text))

# test = print_x(a)    

#include io.stream.h

print('mustakim is', 'pagal '*20)


print('hello world')