"""Read Interior Finishes & write to Architecture File"""

__title__ = "Read\nInterior\nFinishes"
__author__= "roshan"

import os.path as os


from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from itertools import chain

logger = script.get_logger()
# if__name__ == '__main__':
source_file = forms.pick_file(file_ext='xls')
  
####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

#####################################################################################################################

# Reading an excel file using Python 
import xlrd 
from xlrd import open_workbook 

# Give the location of the file 
# loc = ('C:\Users\A\Desktop\kamlesh\AI FINISH SCHEDULE.xls') 
loc = source_file

#####################################################################################################################

def indices(the_list, val):
    # """Always returns a list containing the indices of val in the_list"""
    retval = []
    last = 0
    while val in the_list[last:]:
             i = the_list[last:].index(val) 
             retval.append(last + i)
             last += i + 1   
    return retval
#####################################################################################################################

# Function to acquire all elements of category & get parameter value by name 

def all_elements_of_category(category):
	return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()

def get_parameter_value_by_name(element, parameterName):
	return element.LookupParameter(parameterName).AsValueString()

#####################################################################################################################
# Building function to look up keys and values (room names and floor finish codes)

def get_all_keys_if_value(d, sought):
    l = list()
    for k, v in d.iteritems():
            if sought in v:
                l.append(k)
    return l

#####################################################################################################################

# Creating fucntion for setting parameter by name

def set_parameter_by_name(element, parameterName, value):
	element.LookupParameter(parameterName).Set(value)
 
#####################################################################################################################

# To open Workbook 
wb = xlrd.open_workbook(loc) 

#####################################################################################################################

# Opening sheet with Floor finishes

sheet = wb.sheet_by_index(0) 

floor_finish_code = sheet.col_values(0)
floor_finish_dimensions = sheet.col_values(4)
floor_finish_area_of_use = sheet.col_values(6)
# print(floor_finish_code)
# print(floor_finish_area_of_use)

floor_finish_str_length_area_of_use = list()
floor_finish_str_length_area_of_use = [len(a) for a in floor_finish_area_of_use]
# print(floor_finish_str_length_area_of_use)

floor_finish_str_length_dimensions = list()
floor_finish_str_length_dimensions = [len(a) for a in floor_finish_str_length_dimensions]

# Identifying list with area of usage as empty/null/none  

floor_finish_area_of_use_None_index = indices(floor_finish_str_length_area_of_use, 0)
floor_finish_dimensions_None_index = indices(floor_finish_str_length_dimensions, 1 )

# Cleaning all lists as per previous

floor_finish_code = [i for j, i in enumerate(floor_finish_code) if j not in floor_finish_area_of_use_None_index]
# print(floor_finish_code)
floor_finish_dimensions = [i for j, i in enumerate(floor_finish_dimensions) if j not in floor_finish_area_of_use_None_index]
# print(floor_finish_dimensions)
floor_finish_area_of_use = [i for j, i in enumerate(floor_finish_area_of_use) if j not in floor_finish_area_of_use_None_index]
# print(floor_finish_area_of_use)

# Splitting the thickness of floor finish

thickness_of_floor_finish = list()
thickness_of_floor_finish = [ i.partition("TH:")[2] for i in floor_finish_dimensions]
thickness_of_floor_finish = [x.replace("mm","") for x in thickness_of_floor_finish]
thickness_of_floor_finish = [x.replace(" ","") for x in thickness_of_floor_finish]
thickness_of_floor_finish = [x.replace("\n","") for x in thickness_of_floor_finish]
str_length_of_thk_of_floor_finish = [len(a) for a in thickness_of_floor_finish]
# print(str_length_of_thk_of_floor_finish)
index_of_str_length_of_floor_finish_None = indices(str_length_of_thk_of_floor_finish, 0)
# print(index_of_str_length_of_floor_finish_None)

thickness_of_floor_finish = [i for j, i in enumerate(thickness_of_floor_finish) if j not in index_of_str_length_of_floor_finish_None]
# print(thickness_of_floor_finish)
floor_finish_code = [i for j, i in enumerate(floor_finish_code) if j not in index_of_str_length_of_floor_finish_None]
# print(floor_finish_code)
floor_finish_area_of_use = [i for j, i in enumerate(floor_finish_area_of_use) if j not in index_of_str_length_of_floor_finish_None]
# print(floor_finish_area_of_use)

#Merge clean list of floor finishes
floor_finish_area_of_use = [x.replace(" ","") for x in floor_finish_area_of_use]
# print(floor_finish_area_of_use)
 
# All elements of category- Rooms

rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
# print(rooms)

# Acquiring Room Names
room_name = list()
room_name = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
room_name_len = [len(r) for r in room_name] 
# print(room_name_len)
index_of_room_name_None = indices(room_name_len, 0)
# print(index_of_room_name_None)
rooms = [i for j, i in enumerate(rooms) if j not in index_of_room_name_None ]
room_name = [i for j, i in enumerate(room_name) if j not in index_of_room_name_None]
# print(rooms)
# y = len(rooms)
# z = len(room_name)
# print(y)
room_name = [x.replace(" ","") for x in room_name]
# print(room_name)

# Building dictionary wit floor finish codes and area of usage

zipObj1 = zip(floor_finish_code,floor_finish_area_of_use)
dict_of_floor_code = dict(zipObj1)
# print(dict_of_floor_code)

#####################################################################################################################


#####################################################################################################################
# Using function to get finish codes 

keys_of_floor_finish = list()
keys_of_floor_finish = [get_all_keys_if_value(dict_of_floor_code,r) for r in room_name]
# print(keys_of_floor_finish)

keys_of_floor_finish = [element for sublist in keys_of_floor_finish for element in sublist]
# print(keys_of_floor_finish)

#####################################################################################################################
# Secondary filter to identify rooms not found in dictionary

room_filter_list = list()
for f in floor_finish_area_of_use:
    f = f.split(",")
    room_filter_list.append(f)
# print(room_filter_list)

# Creating Boolean mask for rooms not found in dictionary

bool_mask_room_list = list()
bool_mask_room_list = [r in chain(*room_filter_list) for r in room_name]
# print(bool_mask_room_list)

# Creating final list of rooms to be added with filtered finish codes

rooms = [i for indx, i in enumerate(rooms) if bool_mask_room_list[indx] == True]
# print(rooms)

#####################################################################################################################


#####################################################################################################################
# Setting floor finishes in Room Parameter - Floor Finish

t = Transaction(doc, 'script')
write_room_pass = list()
write_room_fail = list()

t.Start()
for r in rooms:
    try:
        write_room_pass = [ set_parameter_by_name(r,'Floor Finish' ,f) for r,f in zip(rooms, keys_of_floor_finish)]
    except:
        write_room_fail.append(f)
  
t.Commit()     
# print(write_room_pass)
print(write_room_fail)  
   


####################################################################################################################

# Base Finish

####################################################################################################################

# Opening sheet with Base finishes

sheet = wb.sheet_by_index(1) 

base_finish_code = sheet.col_values(0)
base_finish_dimensions = sheet.col_values(4)
base_finish_area_of_use = sheet.col_values(6)
# print(base_finish_code)
# print(base_finish_area_of_use)

base_finish_str_length_area_of_use = list()
base_finish_str_length_area_of_use = [len(a) for a in base_finish_area_of_use]
# print(base_finish_str_length_area_of_use)

base_finish_str_length_dimensions = list()
base_finish_str_length_dimensions = [len(a) for a in base_finish_str_length_dimensions]

# Identifying list with area of usage as empty/null/none  

base_finish_area_of_use_None_index = indices(base_finish_str_length_area_of_use, 0)
base_finish_dimensions_None_index = indices(base_finish_str_length_dimensions, 1 )

# Cleaning all lists as per previous

base_finish_code = [i for j, i in enumerate(base_finish_code) if j not in base_finish_area_of_use_None_index]
# print(base_finish_code)
base_finish_dimensions = [i for j, i in enumerate(base_finish_dimensions) if j not in base_finish_area_of_use_None_index]
# print(base_finish_dimensions)
base_finish_area_of_use = [i for j, i in enumerate(base_finish_area_of_use) if j not in base_finish_area_of_use_None_index]
# print(base_finish_area_of_use)

# Splitting the thickness of base

thickness_of_base_finish = list()
thickness_of_base_finish = [ i.partition("TH:")[2] for i in base_finish_dimensions]
thickness_of_base_finish = [x.replace("mm","") for x in thickness_of_base_finish]
thickness_of_base_finish = [x.replace(" ","") for x in thickness_of_base_finish]
thickness_of_base_finish = [x.replace("\n","") for x in thickness_of_base_finish]
str_length_of_thk_of_base_finish = [len(a) for a in thickness_of_base_finish]
index_of_str_length_of_base_finish_None = indices(str_length_of_thk_of_base_finish, 0)
# print(index_of_str_length_of_base_finish_None)

thickness_of_base_finish = [i for j, i in enumerate(thickness_of_base_finish) if j not in index_of_str_length_of_base_finish_None]
# print(thickness_of_base_finish)
base_finish_code = [i for j, i in enumerate(base_finish_code) if j not in index_of_str_length_of_base_finish_None]
# print(base_finish_code)
base_finish_area_of_use = [i for j, i in enumerate(base_finish_area_of_use) if j not in index_of_str_length_of_base_finish_None]
# print(base_finish_area_of_use)

# Merge clean list of base finishes
base_finish_area_of_use = [x.replace(" ","") for x in base_finish_area_of_use]
# print(base_finish_area_of_use)
 
# All elements of category- Rooms

rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
# print(rooms)

# Acquiring Room Names
room_name = list()
room_name = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
room_name_len = [len(r) for r in room_name] 
# print(room_name_len)
index_of_room_name_None = indices(room_name_len, 0)
# print(index_of_room_name_None)
rooms = [i for j, i in enumerate(rooms) if j not in index_of_room_name_None ]
room_name = [i for j, i in enumerate(room_name) if j not in index_of_room_name_None]
# print(rooms)

room_name = [x.replace(" ","") for x in room_name]
# print(room_name)

# Building dictionary wit base finish codes and area of usage

zipObj1 = zip(base_finish_code,base_finish_area_of_use)
dict_of_base_code = dict(zipObj1)
# print(dict_of_base_code)

#####################################################################################################################


#####################################################################################################################
# Using function to get finish codes 

keys_of_base_finish = list()
keys_of_base_finish = [get_all_keys_if_value(dict_of_base_code,r) for r in room_name]
# print(keys_of_base_finish)

keys_of_base_finish = [element for sublist in keys_of_base_finish for element in sublist]
# print(keys_of_base_finish)

#####################################################################################################################
# Secondary filter to identify rooms not found in dictionary

room_filter_list = list()
for f in base_finish_area_of_use:
    f = f.split(",")
    room_filter_list.append(f)
# print(room_filter_list)

# Creating Boolean mask for rooms not found in dictionary

bool_mask_room_list = list()
bool_mask_room_list = [r in chain(*room_filter_list) for r in room_name]
# print(bool_mask_room_list)

# Creating final list of rooms to be added with filtered finish codes

rooms = [i for indx, i in enumerate(rooms) if bool_mask_room_list[indx] == True]
# print(rooms)

#####################################################################################################################

#####################################################################################################################
# Setting base finishes in Room Parameter - base Finish

t = Transaction(doc, 'script')
write_room_pass = list()
write_room_fail = list()

t.Start()
for r in rooms:
    try:
        write_room_pass = [ set_parameter_by_name(r,'Base Finish' ,b) for r,b in zip(rooms, keys_of_base_finish)]
    except:
        write_room_fail.append(b)
  
t.Commit()     
# print(write_room_pass)
print(write_room_fail)  
   
####################################################################################################################

# Wall Finish

####################################################################################################################

# Opening sheet with Wall finishes

sheet = wb.sheet_by_index(2) 

wall_finish_code = sheet.col_values(0)
wall_finish_dimensions = sheet.col_values(4)
wall_finish_area_of_use = sheet.col_values(6)
# print(wall_finish_code)
# print(wall_finish_area_of_use)

wall_finish_str_length_area_of_use = list()
wall_finish_str_length_area_of_use = [len(a) for a in wall_finish_area_of_use]
# print(wall_finish_str_length_area_of_use)

wall_finish_str_length_dimensions = list()
wall_finish_str_length_dimensions = [len(a) for a in wall_finish_str_length_dimensions]

# Identifying list with area of usage as empty/null/none  

wall_finish_area_of_use_None_index = indices(wall_finish_str_length_area_of_use, 0)
wall_finish_dimensions_None_index = indices(wall_finish_str_length_dimensions, 1 )

# Cleaning all lists as per previous

wall_finish_code = [i for j, i in enumerate(wall_finish_code) if j not in wall_finish_area_of_use_None_index]
# print(wall_finish_code)
wall_finish_dimensions = [i for j, i in enumerate(wall_finish_dimensions) if j not in wall_finish_area_of_use_None_index]
# print(wall_finish_dimensions)
wall_finish_area_of_use = [i for j, i in enumerate(wall_finish_area_of_use) if j not in wall_finish_area_of_use_None_index]
# print(wall_finish_area_of_use)

# Splitting the thickness of wall

thickness_of_wall_finish = list()
thickness_of_wall_finish = [ i.partition("TH:")[2] for i in wall_finish_dimensions]
thickness_of_wall_finish = [x.replace("mm","") for x in thickness_of_wall_finish]
thickness_of_wall_finish = [x.replace(" ","") for x in thickness_of_wall_finish]
thickness_of_wall_finish = [x.replace("\n","") for x in thickness_of_wall_finish]
str_length_of_thk_of_wall_finish = [len(a) for a in thickness_of_wall_finish]
index_of_str_length_of_wall_finish_None = indices(str_length_of_thk_of_wall_finish, 0)
# print(index_of_str_length_of_wall_finish_None)

thickness_of_wall_finish = [i for j, i in enumerate(thickness_of_wall_finish) if j not in index_of_str_length_of_wall_finish_None]
# print(thickness_of_wall_finish)
wall_finish_code = [i for j, i in enumerate(wall_finish_code) if j not in index_of_str_length_of_wall_finish_None]
# print(wall_finish_code)
wall_finish_area_of_use = [i for j, i in enumerate(wall_finish_area_of_use) if j not in index_of_str_length_of_wall_finish_None]
# print(wall_finish_area_of_use)

# Merge clean list of wall finishes
wall_finish_area_of_use = [x.replace(" ","") for x in wall_finish_area_of_use]
# print(wall_finish_area_of_use)
 
# All elements of category- Rooms

rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
# print(rooms)

# Acquiring Room Names
room_name = list()
room_name = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
room_name_len = [len(r) for r in room_name] 
# print(room_name_len)
index_of_room_name_None = indices(room_name_len, 0)
# print(index_of_room_name_None)
rooms = [i for j, i in enumerate(rooms) if j not in index_of_room_name_None ]
room_name = [i for j, i in enumerate(room_name) if j not in index_of_room_name_None]
# print(rooms)

room_name = [x.replace(" ","") for x in room_name]
# print(room_name)

# Building dictionary wit wall finish codes and area of usage

zipObj1 = zip(wall_finish_code,wall_finish_area_of_use)
dict_of_wall_code = dict(zipObj1)
# print(dict_of_wall_code)

#####################################################################################################################


#####################################################################################################################
# Using function to get finish codes 

keys_of_wall_finish = list()
keys_of_wall_finish = [get_all_keys_if_value(dict_of_wall_code,r) for r in room_name]
# print(keys_of_wall_finish)

keys_of_wall_finish = [element for sublist in keys_of_wall_finish for element in sublist]
# print(keys_of_wall_finish)

#####################################################################################################################
# Secondary filter to identify rooms not found in dictionary

room_filter_list = list()
for f in wall_finish_area_of_use:
    f = f.split(",")
    room_filter_list.append(f)
# print(room_filter_list)

# Creating Boolean mask for rooms not found in dictionary

bool_mask_room_list = list()
bool_mask_room_list = [r in chain(*room_filter_list) for r in room_name]
# print(bool_mask_room_list)

# Creating final list of rooms to be added with filtered finish codes

rooms = [i for indx, i in enumerate(rooms) if bool_mask_room_list[indx] == True]
# print(rooms)

#####################################################################################################################

#####################################################################################################################
# Setting wall finishes in Room Parameter - wall Finish

t = Transaction(doc, 'script')
write_room_pass = list()
write_room_fail = list()

t.Start()
for r in rooms:
    try:
        write_room_pass = [ set_parameter_by_name(r,'Wall Finish' ,w) for r,w in zip(rooms, keys_of_wall_finish)]
    except:
        write_room_fail.append(w)
  
t.Commit()     
# print(write_room_pass)
print(write_room_fail)
   
####################################################################################################################

# Ceiling Finish

####################################################################################################################

# Opening sheet with ceiling finishes

sheet = wb.sheet_by_index(3) 

ceiling_finish_code = sheet.col_values(0)
ceiling_finish_dimensions = sheet.col_values(4)
ceiling_finish_area_of_use = sheet.col_values(6)
# print(ceiling_finish_code)
# print(ceiling_finish_area_of_use)

ceiling_finish_str_length_area_of_use = list()
ceiling_finish_str_length_area_of_use = [len(a) for a in ceiling_finish_area_of_use]
# print(ceiling_finish_str_length_area_of_use)

ceiling_finish_str_length_dimensions = list()
ceiling_finish_str_length_dimensions = [len(a) for a in ceiling_finish_str_length_dimensions]

# Identifying list with area of usage as empty/null/none  

ceiling_finish_area_of_use_None_index = indices(ceiling_finish_str_length_area_of_use, 0)
ceiling_finish_dimensions_None_index = indices(ceiling_finish_str_length_dimensions, 1 )

# Cleaning all lists as per previous

ceiling_finish_code = [i for j, i in enumerate(ceiling_finish_code) if j not in ceiling_finish_area_of_use_None_index]
# print(ceiling_finish_code)
ceiling_finish_dimensions = [i for j, i in enumerate(ceiling_finish_dimensions) if j not in ceiling_finish_area_of_use_None_index]
# print(ceiling_finish_dimensions)
ceiling_finish_area_of_use = [i for j, i in enumerate(ceiling_finish_area_of_use) if j not in ceiling_finish_area_of_use_None_index]
# print(ceiling_finish_area_of_use)

# Splitting the thickness of ceiling

thickness_of_ceiling_finish = list()
thickness_of_ceiling_finish = [ i.partition("TH:")[2] for i in ceiling_finish_dimensions]
thickness_of_ceiling_finish = [x.replace("mm","") for x in thickness_of_ceiling_finish]
thickness_of_ceiling_finish = [x.replace(" ","") for x in thickness_of_ceiling_finish]
thickness_of_ceiling_finish = [x.replace("\n","") for x in thickness_of_ceiling_finish]
str_length_of_thk_of_ceiling_finish = [len(a) for a in thickness_of_ceiling_finish]
index_of_str_length_of_ceiling_finish_None = indices(str_length_of_thk_of_ceiling_finish, 0)
# print(index_of_str_length_of_ceiling_finish_None)

thickness_of_ceiling_finish = [i for j, i in enumerate(thickness_of_ceiling_finish) if j not in index_of_str_length_of_ceiling_finish_None]
# print(thickness_of_ceiling_finish)
ceiling_finish_code = [i for j, i in enumerate(ceiling_finish_code) if j not in index_of_str_length_of_ceiling_finish_None]
# print(ceiling_finish_code)
ceiling_finish_area_of_use = [i for j, i in enumerate(ceiling_finish_area_of_use) if j not in index_of_str_length_of_ceiling_finish_None]
# print(ceiling_finish_area_of_use)

# Merge clean list of ceiling finishes
ceiling_finish_area_of_use = [x.replace(" ","") for x in ceiling_finish_area_of_use]
# print(ceiling_finish_area_of_use)
 
# All elements of category- Rooms

rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
# print(rooms)

# Acquiring Room Names
room_name = list()
room_name = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
room_name_len = [len(r) for r in room_name] 
# print(room_name_len)
index_of_room_name_None = indices(room_name_len, 0)
# print(index_of_room_name_None)
rooms = [i for j, i in enumerate(rooms) if j not in index_of_room_name_None ]
room_name = [i for j, i in enumerate(room_name) if j not in index_of_room_name_None]
# print(rooms)

room_name = [x.replace(" ","") for x in room_name]
# print(room_name)

# Building dictionary wit ceiling finish codes and area of usage

zipObj1 = zip(ceiling_finish_code,ceiling_finish_area_of_use)
dict_of_ceiling_code = dict(zipObj1)
# print(dict_of_ceiling_code)

#####################################################################################################################


#####################################################################################################################
# Using function to get finish codes 

keys_of_ceiling_finish = list()
keys_of_ceiling_finish = [get_all_keys_if_value(dict_of_ceiling_code,r) for r in room_name]
# print(keys_of_ceiling_finish)

keys_of_ceiling_finish = [element for sublist in keys_of_ceiling_finish for element in sublist]
# print(keys_of_ceiling_finish)

#####################################################################################################################
# Secondary filter to identify rooms not found in dictionary

room_filter_list = list()
for f in ceiling_finish_area_of_use:
    f = f.split(",")
    room_filter_list.append(f)
# print(room_filter_list)

# Creating Boolean mask for rooms not found in dictionary

bool_mask_room_list = list()
bool_mask_room_list = [r in chain(*room_filter_list) for r in room_name]
# print(bool_mask_room_list)

# Creating final list of rooms to be added with filtered finish codes

rooms = [i for indx, i in enumerate(rooms) if bool_mask_room_list[indx] == True]
# print(rooms)

#####################################################################################################################

#####################################################################################################################
# Setting ceiling finishes in Room Parameter - ceiling Finish

t = Transaction(doc, 'script')
write_room_pass = list()
write_room_fail = list()

t.Start()
for r in rooms:
    try:
        write_room_pass = [ set_parameter_by_name(r,'Ceiling Finish' ,c) for r,c in zip(rooms, keys_of_ceiling_finish)]
    except:
        write_room_fail.append(c)
  
t.Commit()     
# print(write_room_pass)
print(write_room_fail)


#####################################################################################################################

#Finish

#####################################################################################################################