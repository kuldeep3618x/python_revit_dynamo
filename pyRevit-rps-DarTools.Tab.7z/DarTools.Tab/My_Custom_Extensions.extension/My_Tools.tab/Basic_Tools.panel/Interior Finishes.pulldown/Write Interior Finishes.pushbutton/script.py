"""Write Interior Finishes & write to Interior File"""

__title__ = "Write\nInterior\nFinishes"
__author__= "Roshan_John"

import os.path as os
import os.path as op

from pyrevit.coreutils import envvars
from decimal import *

from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from pyrevit import revit, DB, UI
from pyrevit.revit import query
from pyrevit import USER_DESKTOP
from pyrevit import framework
from pyrevit import HOST_APP

from itertools import chain

logger = script.get_logger()
# # if__name__ == '__main__':
# source_file = forms.pick_file(file_ext='xls')
  
####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

#####################################################################################################################

# def read_links(linktype=DB.ExternalFileReferenceType.RevitLink.collector):
#     try:
#         extref = query.get_links(linktype)
#         for ref in extref:
#             logger.debug(ref)
        
#         if extref:
#             refcount = len(extref)
#             if refcount == 1:
#                 selected_extref = \
#                     forms.SelectFromList.show(
#                     extref,
#                     title = 'Select Links to Read Finishes', 
#                     width = 500, 
#                     button_name = 'Read Link', 
#                     multiselect = False
#                     )
#                 if not selected_extref:
#                     script.exit()
#             elif refcount > 1:
#                 logger.debug('Load one model information at a time')
            
#             for extref in selected_extref:
#                 a = selected_extref.GetLinkDocument()
#                 b = FilteredElementCollector(a).OfCategory(BuiltInCategory.OST_Rooms)
#     except:
#         forms.alert('Error in selection')
        
# linktypes = {'Revit Links': DB.ExternalFileReferenceType.RevitLink}   

# if len(linktypes) == 1:
#     selected_option = 'RevitLinks'
# else:
#     logger.debug('Load one model information at a time')

# read_list = []    
# if selected_option:
#     read_links(linktypes[selected_option],b)

# print(read_list)   
        
    
    
# linktypes = {'Revit Links': DB.ExternalFileReferenceType.RevitLink}

# x = list()
# if linktypes == 'Revit Links':
#     x = read_links(linktypes[collector])


#####################################################################################################################

# The inputs to this node will be stored as a list in the IN variables.



"""Change the selected sheet names."""
#pylint: disable=import-error,invalid-name
from pyrevit import revit
from pyrevit import forms



selection = revit.get_selection()

linkInstance = selection
linkedDoc = linkInstance.GetLinkDocument()
collector = FilteredElementCollector(linkedDoc).OfCategory(BuiltInCategory.OST_Rooms)

sel_sheets = forms.select_sheets(title='Select Sheets')

if sel_sheets:
    selection.set_to(sel_sheets)
print(collector)

class WriteInteriorFinishes(forms.WPFWindow) :
    def __init__(self,xaml_file_name):
        self.linked_models = []
        
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.find_linked_models()
    
    def _find_linked_models(self):
        cl = DB.FilteredElementCollector(revit.doc)
        all_linked_models = \
                cl.OfClass(framework.get_type(DB.RevitLinkType)).ToElements()
        self.linked_models = [lm for lm in all_linked_models
                              if DB.RevitLinkType.IsLoaded(revit.doc, lm.Id)]
        self.linkedmodels_lb.ItemsSource = self.linked_models
        self.linkedmodels_lb.SelectedIndex = 0
    
    def _get_linked_model_doc(self):
        linked_model = self.linkedmodels_lb.SelectedItem
        for open_doc in revit.docs:
            if open_doc.Title == revit.query.get_name(linked_model):
                return open_doc
    
    def _list_rooms(self):
        open_doc = self._get_linked_model_doc()
        linked_rooms = FilteredElementCollector(open_doc).OfCategory(BuiltInCategory.OST_Rooms)
    
    def linked_model_selected(self, sender, args):
        self._list_rooms()
        
     
   
   
   
           
    
    
WriteInteriorFinishes('Write_Interior_Finishes.xaml').ShowDialog()