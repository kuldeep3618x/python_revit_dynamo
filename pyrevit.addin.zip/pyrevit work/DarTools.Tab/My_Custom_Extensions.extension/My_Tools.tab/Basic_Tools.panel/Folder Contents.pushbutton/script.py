from __future__ import division

"""Advanced_Folder_Read"""

__title__ = "Folder\nContents"
__author__= "kamlesh"

import sys
import clr
import math
import rpw
import Autodesk
import itertools





####################################################

clr.AddReference('Microsoft.Office.Interop.Excel, Version=11.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c')
from Microsoft.Office.Interop import Excel
from System.Runtime.InteropServices import Marshal

####################################################
import os.path as os
from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from itertools import chain



logger = script.get_logger()
# if__name__ == '__main__':
source_file = forms.pick_file(file_ext='xlsx')
loc = source_file

# import clr
# # import the Excel Interop. 
# clr.AddReference('Microsoft.Office.Interop.Excel, Version=11.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c')
# from Microsoft.Office.Interop import Excel
# from System.Runtime.InteropServices import Marshal
# file path of excel file. 
path = loc

# Instantiate the Excel Application
ex = Excel.ApplicationClass()
# Make it Visiable for us all to see
ex.Visible = False
# Disable Alerts - Errors Ignore them, they're probably not important
ex.DisplayAlerts = False
# Workbook 
workbook = ex.Workbooks.Open(loc)
# WorkSheet
ws = workbook.Worksheets[1]

# trial2
# i = 1
# cell=0
# big_data ={}
# while cell!=  None:
#     row = ws.Rows[i]
#     cell = row.Value[0,0]
#     if cell == None:
#         break
#     else:
#         big_data[cell] = [row.Value[0,1], row.Value[0,2]]
#     i=i+1
    

# ex.ActiveWorkbook.Close(False)
# Marshal.ReleaseComObject(ws)
# Marshal.ReleaseComObject(workbook)
# Marshal.ReleaseComObject(ex)

# flatten_list = list()
# flatten_list = list(chain.from_iterable(big_data))
# flatten_list = str(flatten_list)

# print(flatten_list)










# Cell range
x1range = ws.Range["A1", "A5"]
x2range = ws.Range["B1", "B5"]
r1 = list()
r2 = list() 
r1 = x1range.Value2
r2 = x2range.Value2

# OUT = r1, r2
# close and release excel file from memory. 
ex.ActiveWorkbook.Close(False)
Marshal.ReleaseComObject(ws)
Marshal.ReleaseComObject(workbook)
Marshal.ReleaseComObject(ex)

flatten_list = list()
flatten_list = list(chain.from_iterable(r1))
flatten_list = str(flatten_list)

print(flatten_list)


























# Browse Excel File

# ex = Excel.ApplicationClass()
# ex.Visible = False
# ex.DisplayAlerts = False
# commands = [CommandLink('Browse',return_value='Open')]
# dialog = TaskDialog('Select Excel File ')
# dialog.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Browse")
# dialog.CommonButtons = TaskDialogCommonButtons.Close
# dialog.DefaultButton = TaskDialogResult.Close
# tResult = dialog.Show()
# if TaskDialogResult.CommandLink1 == tResult:
#     path = select_file('Excel (*.xlsx)|*.xlsx')
# workbook = ex.Workbooks.Open(path)
# ws = workbook.worksheets[0]
# i=1
# cell=0
# Families_Dic ={}
# while cell!= None:
#     row = ws.Rows[i]
#     cell = row.Value2[0, 0]
#     if cell == None:
#         break
#     else:
#         Families_Dic[cell] = [row.Value2[0, 1], row.Value2[0, 2]]
#     i=i+1

# print(Families_Dic)