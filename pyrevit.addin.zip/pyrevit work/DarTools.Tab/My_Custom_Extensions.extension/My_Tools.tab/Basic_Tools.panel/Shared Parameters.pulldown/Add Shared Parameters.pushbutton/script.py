"""Occupancy Calcuations"""

__title__ = "Add_Shared\nParameters\nto_file"
__author__= "J K Roshan\nKerketta"

from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from itertools import chain


#Select Excel File from Folder

logger = script.get_logger()
# if__name__ == '__main__':
source_file = forms.pick_file(file_ext='xls')
####################################################################################################################
import clr
# import System
import System
from System.Collections.Generic import *
# import Revit API
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *
# import Revit Services 
clr.AddReference('RevitServices')
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
# import Revit API User Interface UI
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.UI import *
from Autodesk.Revit import Creation
# get the current Revit Document 
doc = DocumentManager.Instance.CurrentDBDocument
# get the user interface document 
uidoc = DocumentManager.Instance.CurrentUIDocument

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
# uiapp = DocumentManager.Instance.CurrentUIApplication
# app = uiapp.Application

####################################################################################################################

import clr
# import System
import System
from System.Collections.Generic import *
# import Revit API
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *
# import Revit Services 
clr.AddReference('RevitServices')
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager
# import Revit API User Interface UI
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.UI import *
from Autodesk.Revit import Creation
# # get the current Revit Document 
# doc = DocumentManager.Instance.CurrentDBDocument
# # get the user interface document 
# uidoc = DocumentManager.Instance.CurrentUIDocument
# # get the Revit application. 
app = doc.Application


####################################################################################################################
# Reading an excel file using Python 
import xlrd 
from xlrd import open_workbook 

# Give the location of the file 
loc = source_file
  
# To open Workbook 
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
  
####################################################################################################################



#####################################################################################################################
####USER INPUT FROM EXCEL#####


_paramName = sheet.col_values(1)    #string
_groupName = sheet.col_values(2)    #string
_paramType = sheet.col_values(3)    #string
_visible = sheet.col_values(4)      #boolean    convert to boolean
_category = sheet.col_values(5)     #string     categoryID to be extracted from category Name
_paramGroup = sheet.col_values(6)   #string
_instance = sheet.col_values(7)     #boolean    convert to boolean

#####################################################################################################################
def str_parameters(_paraVal):
	for x in _paraVal:
		return str(x)		

_paramName = str_parameters(_paramName)
_groupName = str_parameters(_groupName)
_paramType = str_parameters(_paramType)
_visible = str_parameters(_visible)
_category = str_parameters(_category)
_paramGroup = str_parameters(_paramGroup)
_instance = str_parameters(_instance)

print(_paramName,_instance,_paramGroup)

# #####################################################################################################################

sharedParameterFile =app.OpenSharedParameterFile()
Groups = sharedParameterFile.Groups

externalDefinition = []
for g in Groups:
	definition = g.Definitions
	for d in definition:
		externalDefinition.append(d)


for i in externalDefinition:
	for j,b,pg in zip(_paramName,_instance,_paramGroup):
		s = "PG_"
		bpg = [ s + i for i in pg]
		print(bpg)
		# bpg = pg.Insert(0, "PG_")
		bool = b.startswith('I')
		exec("bpg = BuiltInParameterGroup.%s" % bpg)
		
		# if i.Name == j:

# 			t = Transaction(doc, 'script')
# 			t.Start()
# 			newInstanceBinding = app.Create.NewInstanceBinding(cats)
# 			doc.ParameterBindings.Insert(i,newInstanceBinding ,bpg)
# 			t.commit()
# 			app.sharedParameterFilename = orignial_sharedParameterFile











































############################################################################################