"""Occupancy Calcuations"""

__title__ = "Occupancy\nCalculations"
__author__= "J K Roshan\nKerketta"

######################################################################

import time
start = time.time()

####################################################################################################################
import itertools
import operator

from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from pyrevit.api import UI  
from pyrevit import revit, DB

from itertools import chain
from itertools import islice
from pyrevit import HOST_APP

out = script.get_output()
out.add_style('body{font-family: CenturyGothic; font-size: 12pt; }')

####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

from System.Collections.Generic import * 

import clr
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *

clr.AddReference('ProtoGeometry')                       
from Autodesk.DesignScript.Geometry import *            
        
clr.AddReference("RevitNodes")                          
import Revit                                            
clr.ImportExtensions(Revit.Elements)                    
clr.ImportExtensions(Revit.GeometryConversion)         

clr.AddReference("RevitServices")                       
import RevitServices                                    
from RevitServices.Persistence import DocumentManager    

####################################################################################################################

doc = __revit__.ActiveUIDocument.Document

uiapp = DocumentManager.Instance.CurrentUIApplication   
app = uiapp.Application                                

uidoc = __revit__.ActiveUIDocument
activeV = doc.ActiveView

##################################################################################################################

# Reading an excel file using Python 
import xlrd 
from xlrd import open_workbook 

# Select Excel File from Folder

logger = script.get_logger()
source_file = forms.pick_file(file_ext='xlsx')

# Give the location of Excel the file 
loc = source_file

# To open Workbook 
wb = xlrd.open_workbook(loc)
occcupancy_type_sheet = wb.sheet_by_index(0) 

#####################################################################################################################
# Read Excel Parameters and Family Category

# Column values in Excel File
occupancy_type_identity = occcupancy_type_sheet.col_values(1)
occupancy_factor_NBC = occcupancy_type_sheet.col_values(2)
occupancy_factor_SBC = occcupancy_type_sheet.col_values(3)
occupancy_factor_IBC = occcupancy_type_sheet.col_values(4)
occupancy_factor_NFPA = occcupancy_type_sheet.col_values(5)
occupancy_factor_DCD = occcupancy_type_sheet.col_values(6)
occupancy_factor_BS = occcupancy_type_sheet.col_values(7)
occupancy_factor_FN = occcupancy_type_sheet.col_values(8)

occupancy_type_dictionary = {z[0]:list(z[1:]) for z in zip(occupancy_type_identity, occupancy_factor_NBC, occupancy_factor_SBC, occupancy_factor_IBC, occupancy_factor_NFPA, occupancy_factor_DCD, occupancy_factor_BS, occupancy_factor_FN)}

####################################################################################################################


def format_length(length_value, doc = None):
    doc = doc or HOST_APP.doc
    return DB.UnitFormatUtils.Format(units = doc.GetUnits(), unitType = DB.UnitType.UT_Length, value = length_value, maxAccuracy = False, forEditing =False)

def format_area(area_value, doc = None):
    doc = doc or HOST_APP.doc
    return DB.UnitFormatUtils.Format(units = doc.GetUnits(), unitType = DB.UnitType.UT_Area, value = area_value, maxAccuracy = False, forEditing =False)

####################################################################################################################
# Function to acquire all elements of category & get parameter value by name 

def all_elements_of_category(category):
	return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()

####################################################################################################################
# Function to read Shared Parameter values as String

def shared_parameter_values(elems, parameter_name):
    elem_param_values = []
    for e in elems:
        for param in e.Parameters:
            if param.IsShared and param.Definition.Name == parameter_name:
                paramValue = e.get_Parameter(param.GUID)
                elem_param_values.append(paramValue.AsString())
    return elem_param_values

####################################################################################################################
# Function to write Shared Parameter values

def set_parameter_by_name(element, parameterName, value):
	element.LookupParameter(parameterName).Set(value)

####################################################################################################################
# Perform Set Parameter By Name as a Transaction

def set_parameter_by_name_transaction(sample_elements, sample_param_name, sample_param_values):
    
    t = Transaction(doc, 'script')
    write_param_pass = []
    write_param_fail = []
    t.Start()
    for e in sample_elements:
        try:
            write_param_pass = [set_parameter_by_name(e,sample_param_name,val) for e,val in zip(sample_elements, sample_param_values)]
        except:
            write_param_fail.append(val)
    t.Commit()  

#####################################################################################################################

def unit_conversion_area(revit_area_value_in_feet):
    resultant_area_value_from_revit = [float(x) for x in revit_area_value_in_feet]
    resultant_area_value_unit_conversion = [format_area(x) for x in resultant_area_value_from_revit]
    resultant_area_value_converted_to_meters = [float(x) for x in resultant_area_value_unit_conversion]
    return(resultant_area_value_converted_to_meters)

#####################################################################################################################

# Function to print Output statements for None & Invalid Types

def output_statement(sample_room_selections, sample_room_num_with_issues, sample_room_name_with_issues):
       
    sample_test_issues = [zip(sample_room_selections, sample_room_num_with_issues, sample_room_name_with_issues)]  
    
    for issues in sample_test_issues:
        out.print_table(table_data = issues, title = 'OCCUPANCY CHECKING TABLE', columns = ['Element ID', 'Room Number', 'Room Name'], formats = ['','',''])
                     
######################################################################################################################
# Acquireing Rooms 
                                
rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
room_numbers = [r.get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString() for r in rooms]
# print(room_numbers)
room_names = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
# print(room_name)

######################################################################################################################
# Get Room Occupancy Type

test_room_occupancy_type = [r.get_Parameter(BuiltInParameter.ROOM_OCCUPANCY).AsString() for r in rooms]
# print(test_room_occupancy_type) 

######################################################################################################################
# Rooms with no Occupancy Type

filter_rooms_with_no_occupancy_type_index = [ i for i, x in enumerate(test_room_occupancy_type) if x == None]
rooms_with_no_occupancy_type =[ rooms[i] for i in filter_rooms_with_no_occupancy_type_index ]
rooms_numbers_with_no_occupancy_type = [room_numbers[i] for i in filter_rooms_with_no_occupancy_type_index]
room_names_with_no_occupancy_type = [room_names[i] for i in filter_rooms_with_no_occupancy_type_index]
room_Selections_with_no_occupancy_type = [out.linkify(r.Id) for r in rooms]
print('*'*216)
if len(room_names_with_no_occupancy_type) == 0:
    print('All Rooms have Occupancy Type Assigned')
else:
    print('The following Rooms have no Occupancy Type assigned:')
    rooms_with_no_occupancy_type_issue = output_statement(room_Selections_with_no_occupancy_type,rooms_numbers_with_no_occupancy_type,room_names_with_no_occupancy_type ) 
print('*'*216)

######################################################################################################################
# Filtered Rooms with Occupancy Type

filter_rooms_with_occupancy_type_index = [i for i, x in enumerate(test_room_occupancy_type) if x != None] 
# print(filter_rooms_with_occupancy_type_index)

rooms_with_occupancy_type = [rooms[i] for i in filter_rooms_with_occupancy_type_index]
rooms_numbers_with_occupancy_type = [room_numbers[i] for i in filter_rooms_with_occupancy_type_index]
room_names_with_occupancy_type = [room_names[i] for i in filter_rooms_with_occupancy_type_index]
room_occupancy_type = [test_room_occupancy_type[i] for i in filter_rooms_with_occupancy_type_index]
# print(room_occupancy_type)

######################################################################################################################
# Rooms with Invalid Occupancy Type

room_occupancy_type_invalid = list((set(room_occupancy_type).difference(occupancy_type_identity)))
index_of_invalid_room_occupancy_type = []
for i in range(len(room_occupancy_type)):
    if room_occupancy_type[i] in room_occupancy_type_invalid:
        index_of_invalid_room_occupancy_type.append(i)
# print(index_of_invalid_room_occupancy_type)

rooms_with_invalid_occupancy_type = [rooms_with_occupancy_type[i] for i in index_of_invalid_room_occupancy_type]
rooms_numbers_with_invalid_occupancy_type = [rooms_numbers_with_occupancy_type[i] for i in index_of_invalid_room_occupancy_type]
room_names_with_invalid_occupancy_type = [room_names_with_occupancy_type[i] for i in index_of_invalid_room_occupancy_type]
room_occupancy_type_invalid = [room_occupancy_type[i] for i in index_of_invalid_room_occupancy_type]
room_Selections_with_invalid_occupancy_type = [out.linkify(r.Id) for r in rooms_with_invalid_occupancy_type]
# print(room_occupancy_type_invalid)

if len(room_occupancy_type_invalid) == 0:
    print('All Rooms with Occupancy Type provided are valid')
else:
    print('The following Rooms have invalid Occupancy Type assigned.\nVERY IMPORTANT- Please fix all invalid Occupancy Types, it will cause incorrect calculations.')
    rooms_with_invalid_occupancy_type_issue = output_statement(room_Selections_with_invalid_occupancy_type, rooms_numbers_with_invalid_occupancy_type,room_names_with_invalid_occupancy_type) 
print('*'*216)

######################################################################################################################
# Rooms with Valid Occupancy Type

set_index_of_invalid_room_occupancy_type = set(index_of_invalid_room_occupancy_type) 
rooms_with_valid_occupancy_type = [e for i, e in enumerate(rooms_with_occupancy_type) if i not in set_index_of_invalid_room_occupancy_type]
room_valid_occupancy_types = [e for i, e in enumerate(room_occupancy_type) if i not in set_index_of_invalid_room_occupancy_type]
# print(room_valid_occupancy_types)

area_in_rooms_with_valid_occupancy_type = [ar.get_Parameter(BuiltInParameter.ROOM_AREA).AsDouble() for ar in rooms_with_valid_occupancy_type]
area_in_rooms_with_valid_occupancy_type = unit_conversion_area(area_in_rooms_with_valid_occupancy_type)
area_in_rooms_with_valid_occupancy_type = [1 if x == 0 else x for x in area_in_rooms_with_valid_occupancy_type]
# print(area_in_rooms_with_valid_occupancy_type)

####################################################################################################################

# Occupant Count Calculation

def occupant_count_calculation(sheet_col_for_code):
    values_from_dict_code = [occupancy_type_dictionary[x][sheet_col_for_code] for x in room_valid_occupancy_types]
        
    ################################################################################################################
    # Filter Rooms, Occupancies with values from Dictionaries not as 'NA'
    
    filter_occupancy_values_index_with_non_NA = [i for i, x in enumerate(values_from_dict_code) if x != 'NA']
    rooms_with_valid_occupancy_values = [rooms_with_valid_occupancy_type[i] for i in  filter_occupancy_values_index_with_non_NA]
    room_valid_occupancy_values = [values_from_dict_code[i] for i in filter_occupancy_values_index_with_non_NA]
    area_in_rooms_with_valid_occupancy_values = [area_in_rooms_with_valid_occupancy_type[i] for i in filter_occupancy_values_index_with_non_NA]
    occupant_count_as_per_code = [x/y for x,y in zip(map(float, area_in_rooms_with_valid_occupancy_values), map(float, room_valid_occupancy_values))]
    
    ################################################################################################################
    # Calculate Occupant Count
        
    occupant_count_as_per_code = [long(round(oc)) for oc in occupant_count_as_per_code]
    occupant_count_as_per_code = [int(oc) for oc in occupant_count_as_per_code]
    occupant_count_as_per_code = [ 1 if x == 0 else x for x in occupant_count_as_per_code]
    occupant_count_total = sum(occupant_count_as_per_code)

    ################################################################################################################
    # Calculating Floor Level Occupancies 
          
    room_level_name = [r.Level.Name for r in rooms_with_valid_occupancy_values]
    room_level_elevation = [r.Level.Elevation for r in rooms_with_valid_occupancy_values]
      
    temp_list = []
    for i in range(len(room_level_elevation)):
        temp_list.append([room_level_elevation[i], i])
    temp_list.sort()
    
    index_of_room_level_sorted = []
    for x in temp_list:
        index_of_room_level_sorted.append(x[1])

    sorted_room_level_elevation_name = [room_level_name[i] for i in index_of_room_level_sorted]
    create_sublist_by_level_name = [list(y) for x,y in itertools.groupby(sorted_room_level_elevation_name)]
    
    length_of_sublist_of_level_name = [len(x) for x in create_sublist_by_level_name]
    
    sorted_rooms_by_level = [rooms_with_valid_occupancy_values[i] for i in index_of_room_level_sorted]
    create_sublist_for_rooms = iter(sorted_rooms_by_level)
    create_sublist_for_rooms = [list(islice(create_sublist_for_rooms, elem)) for elem in length_of_sublist_of_level_name]

    sorted_room_level_elevation = [room_level_elevation[i] for i in index_of_room_level_sorted]
    create_sublist_for_levels_of_rooms = iter(sorted_room_level_elevation)
    create_sublist_for_levels_of_rooms = [list(islice(create_sublist_for_levels_of_rooms, elem)) for elem in length_of_sublist_of_level_name]
    
    sorted_room_valid_occupancy_values = [room_valid_occupancy_values[i] for i in index_of_room_level_sorted] 
    create_sublist_for_room_valid_occupancy_values_by_level = iter(sorted_room_valid_occupancy_values)
    create_sublist_for_room_valid_occupancy_values_by_level = [list(islice(create_sublist_for_room_valid_occupancy_values_by_level, elem)) for elem in length_of_sublist_of_level_name]
    
    sorted_room_occupant_count_by_level = [occupant_count_as_per_code[i] for i in index_of_room_level_sorted]
    create_sublist_for_room_occupant_count_by_level = iter(sorted_room_occupant_count_by_level)
    create_sublist_for_room_occupant_count_by_level = [list(islice(create_sublist_for_room_occupant_count_by_level, elem)) for elem in length_of_sublist_of_level_name]
    length_of_sublist_for_occupant_count = [len(x) for x in create_sublist_for_room_occupant_count_by_level]
    
    sum_of_occupancy_count_for_each_level = [sum(x) for x in create_sublist_for_room_occupant_count_by_level]
    
    unique_room_level_names = [set(x) for x in create_sublist_by_level_name]
    unique_room_level_names = [list(x) for x in unique_room_level_names]    
    unique_room_level_names = [item for sublist in unique_room_level_names for item in sublist]
    
    ################################################################################################################################
        
    # Clean Existing Room values
    
    room_count = len(rooms)
    list_of_default_values = [''] * room_count
    reset_all_room_occupancies = set_parameter_by_name_transaction(rooms, 'Room_Occupant', list_of_default_values)
                                                                                   
    ################################################################################################################################
    # Write Occupancy Values
    
    occupant_count_as_per_code_for_writing_to_param = [ str(oc) for oc in occupant_count_as_per_code]
    write_occupant_count_to_rooms = set_parameter_by_name_transaction(rooms_with_valid_occupancy_values, 'Room_Occupant', occupant_count_as_per_code_for_writing_to_param)
          
    ################################################################################################################################
    # Write Occupancy Values as 'NA' for Rooms with no Occupant count
    
    filter_occupancy_values_index_with_NA = [ i for i, x in enumerate(values_from_dict_code) if x == 'NA']
    rooms_with_NA_occupancy_values = [rooms_with_valid_occupancy_type[i] for i in filter_occupancy_values_index_with_NA]
    room_NA_occupancy_values = [values_from_dict_code[i] for i in filter_occupancy_values_index_with_NA]

    write_occupant_count_NA_to_rooms_with_no_occupancy_type = set_parameter_by_name_transaction(rooms_with_NA_occupancy_values, 'Room_Occupant', room_NA_occupancy_values)
          
    ################################################################################################################  
    return(occupant_count_total, unique_room_level_names, sum_of_occupancy_count_for_each_level, create_sublist_for_rooms, create_sublist_for_room_occupant_count_by_level)
             
####################################################################################################################  
  
####################################################################################################################  

def output_statement_for_rooms_of_each_level(sample_unique_room_level_names, sample_sum_of_occupancy_count_for_each_level):
    
    sample_sum_of_occupancy_count_for_each_level_output = [str(x) for x in sample_sum_of_occupancy_count_for_each_level]
    sample_occupancy_by_level_output = [zip(sample_unique_room_level_names, sample_sum_of_occupancy_count_for_each_level_output)]
    
    for occ_total in sample_occupancy_by_level_output:
        out.print_table(table_data = occ_total, title = 'OCCUPANT COUNT BY FLOOR TABLE', columns = ['Level','Total Occupants'], formats = ['',''])


#################################################################################################################### 

def process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_code, code):
   
    occupant_count_total_as_per_code= occupancy_calculation_as_per_code[0]
    occupant_level_name_as_per_code= occupancy_calculation_as_per_code[1]
    occupant_count_for_each_level_as_per_code= occupancy_calculation_as_per_code[2]
    out.print_md("**The Total Occupant Count for the building, as per {} code is : {} persons.**".format(code,occupant_count_total_as_per_code))
    print('*'*216)
    occupancy_calculation_per_level_as_per_code= output_statement_for_rooms_of_each_level(occupant_level_name_as_per_code,  occupant_count_for_each_level_as_per_code)
    print('*'*216)
 
  
####################################################################################################################
from rpw.ui.forms import SelectFromList
from rpw.utils.coerce import to_category 

####################################################################################################################    

userInputcategory = SelectFromList('Select Fire Code to analyse for the Building.', ['01.NBC', '02.SBC', '03.IBC', '04.NFPA', '05.DCD', '06.BS', '07.FN'])
userInputcategory = str(userInputcategory)

######################################################################################################################
if userInputcategory == '01.NBC':
    occupancy_calculation_as_per_NBC = occupant_count_calculation(0)
    process_NBC_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_NBC, 'NBC')
    
######################################################################################################################
elif userInputcategory == '02.SBC':
    occupancy_calculation_as_per_SBC = occupant_count_calculation(1)
    process_SBC_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_SBC, 'SBC')
    
######################################################################################################################   
elif userInputcategory == '03.IBC':
    occupancy_calculation_as_per_IBC = occupant_count_calculation(2)
    process_IBC_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_IBC, 'IBC')
 
#####################################################################################################################
elif userInputcategory == '04.NFPA':
    occupancy_calculation_as_per_NFPA = occupant_count_calculation(3)
    process_NFPA_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_NFPA, 'NFPA')

######################################################################################################################
elif userInputcategory == '05.DCD':
    occupancy_calculation_as_per_DCD = occupant_count_calculation(4)
    process_DCD_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_DCD, 'DCD')
 
######################################################################################################################
elif userInputcategory == '06.BS':
    occupancy_calculation_as_per_BS = occupant_count_calculation(5)
    process_BS_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_BS, 'BS')
    
######################################################################################################################
elif userInputcategory == '07.FN':
    occupancy_calculation_as_per_FN = occupant_count_calculation(6)
    process_FN_calculations = process_occupant_count_calc_as_per_sel_code(occupancy_calculation_as_per_FN, 'FN')
      
######################################################################################################################
else:
    pass

#####################################################################################################################

print ('It took', time.time()-start, 'seconds.')

print('*'*216)  

##################################################################################################################### 









