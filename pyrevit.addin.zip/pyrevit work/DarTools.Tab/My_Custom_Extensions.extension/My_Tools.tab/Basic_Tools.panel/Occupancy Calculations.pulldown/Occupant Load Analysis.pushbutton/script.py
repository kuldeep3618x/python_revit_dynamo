"""Occupancy Load Analysis"""

__title__ = "Occupancy\nLoad\nAnalysis"
__author__= "J K Roshan\nKerketta"

####################################################################################################################
import itertools
import operator



from pyrevit.coreutils import envvars
from decimal import *
from pyrevit import forms
from pyrevit import script
from pyrevit import coreutils
from pyrevit.api import UI  
from pyrevit import revit, DB

from itertools import chain
from itertools import islice
from pyrevit import HOST_APP

from collections import Counter


out = script.get_output()
out.add_style('body{font-family: CenturyGothic; font-size: 12pt; }')


####################################################################################################################

import Autodesk.Revit.DB as DB
from  Autodesk.Revit.DB import FilteredElementCollector, BuiltInCategory, BuiltInParameter, Transaction, TransactionGroup, Workset, SpatialElement
from Autodesk.Revit.DB import FilteredWorksetCollector, WorksetKind, Element

from System.Collections.Generic import * 

import clr
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *

clr.AddReference('ProtoGeometry')                       
from Autodesk.DesignScript.Geometry import *            
        
clr.AddReference("RevitNodes")                          
import Revit                                            
clr.ImportExtensions(Revit.Elements)                    
clr.ImportExtensions(Revit.GeometryConversion)         

clr.AddReference("RevitServices")                       
import RevitServices                                    
from RevitServices.Persistence import DocumentManager    

####################################################################################################################

doc = __revit__.ActiveUIDocument.Document

uiapp = DocumentManager.Instance.CurrentUIApplication   
app = uiapp.Application                                

uidoc = __revit__.ActiveUIDocument
activeV = doc.ActiveView

##################################################################################################################

# Reading an excel file using Python 
import xlrd 
from xlrd import open_workbook 

####################################################################################################################

def format_length(length_value, doc = None):
    doc = doc or HOST_APP.doc
    return DB.UnitFormatUtils.Format(units = doc.GetUnits(), unitType = DB.UnitType.UT_Length, value = length_value, maxAccuracy = False, forEditing =False)

def format_area(area_value, doc = None):
    doc = doc or HOST_APP.doc
    return DB.UnitFormatUtils.Format(units = doc.GetUnits(), unitType = DB.UnitType.UT_Area, value = area_value, maxAccuracy = False, forEditing =False)

####################################################################################################################
# Function to acquire all elements of category & get parameter value by name 

def all_elements_of_category(category):
	return FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements()

####################################################################################################################
# Function to read Shared Parameter values as String

def shared_parameter_values(elems, parameter_name):
    elem_param_values = []
    for e in elems:
        for param in e.Parameters:
            if param.IsShared and param.Definition.Name == parameter_name:
                paramValue = e.get_Parameter(param.GUID)
                elem_param_values.append(paramValue.AsString())
    return elem_param_values

####################################################################################################################
# Acquireing Rooms 
                                
rooms = all_elements_of_category(BuiltInCategory.OST_Rooms)
room_numbers = [r.get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString() for r in rooms]
# print(room_numbers)
room_names = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms]
# print(room_names)

####################################################################################################################

def all_elements_with_type_parameter_AsDouble(sample_doors, door_family_type_parameter):
    door_family_test = []
    door_family_param = []
    
    for d in sample_doors:
        door_type = d.Symbol
        door_family_param = door_type.LookupParameter(door_family_type_parameter)
        temp = []
        if door_family_param:
            temp = door_family_param.AsDouble()
            door_family_test.append(temp)
        else:
            temp = 'fail'
            door_family_test.append(temp)
    return door_family_test

def unit_conversion(revit_value_in_feet):
    resultant_value_from_revit = [float(x) for x in revit_value_in_feet]
    resultant_value_unit_conversion = [format_length(x) for x in resultant_value_from_revit]
    resultant_value_converted_to_mm = [int(x) for x in resultant_value_unit_conversion]
    return(resultant_value_converted_to_mm)

######################################################################################################################
# Acquiring Clean Room List

room_occupant_count = shared_parameter_values(rooms, "Room_Occupant")
# print(room_occupant_count)
exclusions = ["","NA"]

indices_for_empty_room_occupant_exclusions = [i for i, x in enumerate(room_occupant_count) if x not in exclusions]
rooms_with_valid_occupancy_values = [rooms[i] for i in indices_for_empty_room_occupant_exclusions]
room_numbers_with_valid_occupancy_values = [r.get_Parameter(BuiltInParameter.ROOM_NUMBER).AsString() for r in rooms_with_valid_occupancy_values]
room_names_with_valid_occupancy_values = [r.get_Parameter(BuiltInParameter.ROOM_NAME).AsString() for r in rooms_with_valid_occupancy_values]
room_occupancy_type_with_valid_occupancy_values = [r.get_Parameter(BuiltInParameter.ROOM_OCCUPANCY).AsString() for r in rooms_with_valid_occupancy_values]
room_occupant_count = shared_parameter_values(rooms_with_valid_occupancy_values, "Room_Occupant")
room_occupant_count  = [int(x) for x in room_occupant_count ]
# print(room_occupant_count)

room_level_name = [r.Level.Name for r in rooms_with_valid_occupancy_values]
room_level_elevation = [r.Level.Elevation for r in rooms_with_valid_occupancy_values]

temp_list = []
for i in range(len(room_level_elevation)):
    temp_list.append([room_level_elevation[i], i])
temp_list.sort()
    
index_of_room_level_sorted = []
for x in temp_list:
    index_of_room_level_sorted.append(x[1])
      
sorted_room_level_elevation_name = [room_level_name[i] for i in index_of_room_level_sorted]
create_sublist_by_level_name = [list(y) for x,y in itertools.groupby(sorted_room_level_elevation_name)]
# print(create_sublist_by_level_name)  
  
length_of_sublist_of_level_name = [len(x) for x in create_sublist_by_level_name]

sorted_rooms_by_level = [rooms_with_valid_occupancy_values[i] for i in index_of_room_level_sorted]
sorted_room_numbers_with_valid_occupancy_values = [room_numbers_with_valid_occupancy_values[i] for i in index_of_room_level_sorted]
sorted_room_names_with_valid_occupancy_values = [room_names_with_valid_occupancy_values[i] for i in index_of_room_level_sorted]
sorted_room_occupancy_type = [room_occupancy_type_with_valid_occupancy_values[i] for i in index_of_room_level_sorted]
sorted_room_occupant_count  = [room_occupant_count[i] for i in index_of_room_level_sorted]

create_sublist_for_rooms = iter(sorted_rooms_by_level)
create_sublist_for_rooms = [list(islice(create_sublist_for_rooms, elem)) for elem in length_of_sublist_of_level_name]

sorted_room_valid_occupancy_values = [room_occupant_count[i] for i in index_of_room_level_sorted] 
create_sublist_for_room_valid_occupancy_values_by_level = iter(sorted_room_valid_occupancy_values)
create_sublist_for_room_valid_occupancy_values_by_level = [list(islice(create_sublist_for_room_valid_occupancy_values_by_level, elem)) for elem in length_of_sublist_of_level_name]
# print(create_sublist_for_room_valid_occupancy_values_by_level)

sum_of_occupancy_count_for_each_level = [sum(x) for x in create_sublist_for_room_valid_occupancy_values_by_level]
# print(sum_of_occupancy_count_for_each_level)

total_occupant_count_for_building = sum(sum_of_occupancy_count_for_each_level)

unique_room_level_names = [set(x) for x in create_sublist_by_level_name]
unique_room_level_names = [list(x) for x in unique_room_level_names]    
unique_room_level_names = [item for sublist in unique_room_level_names for item in sublist]
# print(unique_room_level_names)

######################################################################################################################
# Acquireing Doors and filtering Doors

allLevels =  FilteredElementCollector(doc).OfClass(Level).WhereElementIsNotElementType().ToElements()
allLevelNames = [l.Name for l in allLevels]
# print(allLevelNames)
allLevelElevations = [l.Elevation for l in allLevels]

temp_list_lvls = []
for i in range(len(allLevelElevations)):
    temp_list_lvls.append([allLevelElevations[i], i])
temp_list_lvls.sort()

index_of_level_sorted = []
for x in temp_list_lvls:
    index_of_level_sorted.append(x[1])

sorted_allLevels = [allLevels[i] for i in index_of_level_sorted]
sorted_allLevelsName = [l.Name for l in sorted_allLevels]
# print(sorted_allLevelsName)

sorted_allLevelId = [l.Id for l in sorted_allLevels]
# print(sorted_allLevelId)

level_filter = [ElementLevelFilter(lId) for lId in sorted_allLevelId]
# print(level_filter)

filtered_door_collector = []

for f in level_filter:
    temp = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Doors).WherePasses(f).WhereElementIsNotElementType().ToElements()
    filtered_door_collector.append(temp)
# print(filtered_door_collector)

index_of_empty = [i for i, x in enumerate(filtered_door_collector) if len(x) < 1]
# print(index_of_empty)

length_of_each_sublist_for_doors = [len(x) for x in filtered_door_collector]
# print(length_of_each_sublist_for_doors)

# flatten_door_list = [item for sublist in filtered_door_collector for item in sublist]
door_comments = []

for sublist in filtered_door_collector:
  
    for d in sublist:
        temp = d.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).AsString()
        door_comments.append(temp)
# print(door_comments)

door_comments = [str(x) for x in door_comments]
split_door_comments_list = iter(door_comments)
split_door_comments_list = [list(islice(split_door_comments_list, elem)) for elem in length_of_each_sublist_for_doors] 

# print(split_door_comments_list)
# print(len(split_door_comments_list))



indices_of_egress_doors = [(val1,val2) for val1,x in enumerate(split_door_comments_list) for val2,y in enumerate(x) if "EGRESS" in y]
# print(indices_of_egress_doors)


tuple_to_list_indices_of_egress_doors= [list(i) for i in indices_of_egress_doors]
# print(tuple_to_list_indices_of_egress_doors)

first_item_of_indices_for_egress_doors = [x[0] for x in tuple_to_list_indices_of_egress_doors]
# print(first_item_of_indices_for_egress_doors)

count_occurences_of_egress_doors_at_level = Counter(first_item_of_indices_for_egress_doors)
# print(count_occurences_of_egress_doors_at_level)

floor_num_for_egress_doors_at_level = count_occurences_of_egress_doors_at_level.keys()
# print(floor_num_for_egress_doors_at_level)

get_occurence_num_for_egress_doors_at_level = count_occurences_of_egress_doors_at_level.values()
# print(get_occurence_num_for_egress_doors_at_level)

second_item_of_indices_for_egress_doors = [x[1] for x in tuple_to_list_indices_of_egress_doors]
# print(second_item_of_indices_for_egress_doors)

sublist_of_filtered_egress_doors_by_level = iter(second_item_of_indices_for_egress_doors)
sublist_of_filtered_egress_doors_by_level = [list(islice(sublist_of_filtered_egress_doors_by_level, elem)) for elem in get_occurence_num_for_egress_doors_at_level]
# print(sublist_of_filtered_egress_doors_by_level)

# filter_level_for_egress_doors = [split_door_comments_list[i] for i in floor_num_for_egress_doors_at_level]
# # print(filter_level_for_egress_doors)


# filter_doors = [tuple([filter_level_for_egress_doors[x][indx] for indx in i])\
#                     if type(i) in [tuple, list] else tuple([filter_level_for_egress_doors[x][i]])\
#                         for x,i in enumerate(sublist_of_filtered_egress_doors_by_level)]

# print(len(filter_doors))


# filtered_doors_by_level_list = [v for i, v in enumerate(filtered_door_collector) if i not in index_of_empty]
# print(len(filtered_doors_by_level_list))

# filtered_doors_by_level_list_comments = [v for i, v in enumerate(filtered_doors_by_level_list) if i not in index_of_empty_comments]
# print(filtered_doors_by_level_list_comments)
# print(len(filtered_doors_by_level_list_comments))
# filter_door_Revit_elements_by_level = [tuple([filtered_doors_by_level_list[x][indx] for indx in i])\
#                                         if type(i) in [tuple, list] else tuple([filtered_doors_by_level_list[x][i]])\
#                                             for x,i in enumerate(sublist_of_filtered_egress_doors_by_level)]
# print(filter_door_Revit_elements_by_level)



# replacements = ["None"]

# for(index, replacement) in zip(index_of_empty, replacements):
#     filtered_door_collector[index] = replacement
# print(filtered_door_collector)

# filtered_door_by_level_list = []
# for filter in filtered_door_collector:
#     if len(filter) < 1 :
#         temp = ['None']
#     else:
#         temp = filter
#     filtered_door_by_level_list.append(temp)

# print(filtered_door_by_level_list)


####################################################################################################################  
# Lookup Door Room Numbers against Room Numbers



# def lookup_doors_in_rooms_as_oc_count_filter(flat_list_rooms_with_oc_count_filtered, filtered_room_names_as_per_oc_count,\
#                                              filtered_room_nums_as_per_oc_count, filtered_room_oc_type_as_per_count_filter, filtered_room_oc_count_as_per_count_filter,  door_room_nums, doors):
#     lookup_doors_in_rooms_as_count_filter = []
#     for search_item in filtered_room_nums_as_per_oc_count:
#         search_result = []   
#         for i in range(len(door_room_nums)):
#             if search_item == door_room_nums[i]:
#                 search_result.append(i)
#         if len(search_result) > 0:
#             lookup_doors_in_rooms_as_count_filter.append(search_result)
#         else:
#             lookup_doors_in_rooms_as_count_filter.append([None])   

#     idx_of_rooms_with_doors_and_oc_as_count_filter = [i for i, x in enumerate(lookup_doors_in_rooms_as_count_filter) if x[0] != None]
#     rnums_with_doors_and_oc_as_count_filter = [filtered_room_nums_as_per_oc_count[i] for i in idx_of_rooms_with_doors_and_oc_as_count_filter]
#     rnames_with_doors_and_oc_as_count_filter = [filtered_room_names_as_per_oc_count[i] for i in idx_of_rooms_with_doors_and_oc_as_count_filter]
#     rooms_with_doors_and_oc_as_count_filter = [flat_list_rooms_with_oc_count_filtered[i] for i in idx_of_rooms_with_doors_and_oc_as_count_filter]
#     room_oc_type_for_rooms_with_doors_and_count_filter = [filtered_room_oc_type_as_per_count_filter[i] for i in idx_of_rooms_with_doors_and_oc_as_count_filter]
#     room_oc_count_for_rooms_with_doors_and_count_filter = [filtered_room_oc_count_as_per_count_filter[i] for i in idx_of_rooms_with_doors_and_oc_as_count_filter]
    
#     # Looking up Doors for clean list of Rooms with doors & Occupancy as per count filter
    
#     final_lookup_doors_in_rooms_with_oc_count_filter = []
#     for search_item in rnums_with_doors_and_oc_as_count_filter:
#         search_result = []
#         for i in range(len(door_room_nums)):
#             if search_item == door_room_nums[i]:
#                 search_result.append(i)
#         if len(search_result)>0:
#             final_lookup_doors_in_rooms_with_oc_count_filter.append(search_result)
#         else:
#             final_lookup_doors_in_rooms_with_oc_count_filter.append(None)
    
#     length_of_sublist_of_doors_in_rooms_with_oc_count_filter = [len(x) for x in final_lookup_doors_in_rooms_with_oc_count_filter]
    
#     # Check Door Room Numbers exist in Rooms with Occupancy as per count filter
    
#     acquire_door_rnums_for_doors_with_oc_count_filter = []
#     for f in final_lookup_doors_in_rooms_with_oc_count_filter:
#         temp = []
#         temp = [door_room_nums[i] for i in f]
#         acquire_door_rnums_for_doors_with_oc_count_filter.append(temp)
    
#     # Check Doors exist in Rooms with Occupancy as per count filter   
    
#     acquire_doors_for_doors_in_rooms_with_oc_count_filter = []
#     for f in final_lookup_doors_in_rooms_with_oc_count_filter:
#         temp = []
#         temp = [doors[i] for i in f]
#         acquire_doors_for_doors_in_rooms_with_oc_count_filter.append(temp)
    
#     # Door List Flattened for acquiring Widths
#     acquire_doors_for_doors_in_rooms_with_oc_count_filter = [item for sublist in acquire_doors_for_doors_in_rooms_with_oc_count_filter for item in sublist]
    
#     # Door Widths in Flattened List and conversion from feet to millimeters
#     acquire_door_widths_for_doors_in_rooms_with_oc_count_filter = all_elements_with_type_parameter_AsDouble(acquire_doors_for_doors_in_rooms_with_oc_count_filter, 'Width')
#     acquire_door_widths_for_doors_in_rooms_with_oc_count_filter = unit_conversion(acquire_door_widths_for_doors_in_rooms_with_oc_count_filter)
    
#     # Create sublist for Door Widths for further assessment
#     create_sublist_of_dwidths_of_doors_in_rooms_with_oc_count_filter = iter(acquire_door_widths_for_doors_in_rooms_with_oc_count_filter)
#     create_sublist_of_dwidths_of_doors_in_rooms_with_oc_count_filter = [list(islice(create_sublist_of_dwidths_of_doors_in_rooms_with_oc_count_filter, elem))\
#                                                                         for elem in length_of_sublist_of_doors_in_rooms_with_oc_count_filter]

#     total_egress_width_for_doors_in_rooms_with_oc_and_dcount_filter = [sum(x) for x in create_sublist_of_dwidths_of_doors_in_rooms_with_oc_count_filter]
      
#     return total_egress_width_for_doors_in_rooms_with_oc_and_dcount_filter, rnums_with_doors_and_oc_as_count_filter, rnames_with_doors_and_oc_as_count_filter,\
#                                                                      rooms_with_doors_and_oc_as_count_filter, room_oc_type_for_rooms_with_doors_and_count_filter, room_oc_count_for_rooms_with_doors_and_count_filter
  
  
# door_assessment_against_rooms = lookup_doors_in_rooms_as_oc_count_filter(sorted_rooms_by_level, sorted_room_names_with_valid_occupancy_values, sorted_room_numbers_with_valid_occupancy_values,\
#                                                                         sorted_room_occupancy_type, sorted_room_occupant_count,  door_room_nums, doors)

# oc_filtered_sublist_of_total_egress_dwidths_of_doors_in_rooms = door_assessment_against_rooms[0]
# oc_filtered_sublist_of_room_nums_with_doors = door_assessment_against_rooms[1]
# oc_filtered_sublist_of_room_names_with_doors = door_assessment_against_rooms[2]
# oc_filtered_sublist_of_rooms_with_doors = door_assessment_against_rooms[3]
# oc_filtered_sublist_of_rooms_occupant_type = door_assessment_against_rooms[4]
# oc_filtered_sublist_of_rooms_occupant_count = door_assessment_against_rooms[5]
# oc_filtered_sublist_of_rooms_element_Id = [out.linkify(room.Id) for room in oc_filtered_sublist_of_rooms_with_doors]

####################################################################################################################
def output_statement_for_occupant_load(sample_level, occupant_count_group):
    output_for_occupant_load_group = [zip(sample_level, occupant_count_group)]
    for output in output_for_occupant_load_group:
        out.print_table(table_data = output, title = 'TOTAL OCCUPANT COUNT ON LEVELS', columns = ['Level', 'Occupant Count'], formats = ['',''])

def output_statement_for_egress_load(sample_level, occupant_count_group, egress_load):
    output_for_occupant_egress_load_group = [zip(sample_level, occupant_count_group, egress_load)]
    for output in output_for_occupant_egress_load_group:
        out.print_table(table_data = output, title = 'TOTAL STAIRCASE EGRESS WIDTH REQUIRED', columns = ['Level', 'Occupant Count', 'Total egress Width Required(mm)'], formats = ['','',''])

# def egress_capacity_factor_analysis_for_doors(egress_factor_capacity_per_Code, filtered_room_oc_count_for_analysis = oc_filtered_sublist_of_rooms_occupant_count):
#     egress_capacity_required_for_room_as_per_code =[(x * egress_factor_capacity_per_Code) for x in filtered_room_oc_count_for_analysis] 
#     return egress_capacity_required_for_room_as_per_code

# def output_statement_for_egress_comparision(oc_sel_door_egress_required, oc_sel_element_id_room = oc_filtered_sublist_of_rooms_element_Id,\
#                                             oc_sel_room_num = oc_filtered_sublist_of_room_nums_with_doors, oc_sel_room_name = oc_filtered_sublist_of_room_names_with_doors,\
#                                             oc_sel_oc_count = oc_filtered_sublist_of_rooms_occupant_count, oc_sel_door_egress_provided = oc_filtered_sublist_of_total_egress_dwidths_of_doors_in_rooms):
#     output_for_egress_door_output_info = [zip(oc_sel_element_id_room, oc_sel_room_num, oc_sel_room_name, oc_sel_oc_count, oc_sel_door_egress_provided, oc_sel_door_egress_required)]
#     for output in output_for_egress_door_output_info:
#         out.print_table(table_data = output, title = "TOTAL DOOR EGRESS WIDTH PROVIDED AGAINST REQUIRED", columns = ['Room Element ID', 'Room Number', 'Room Name',\
#                                                                                                                     'Occupant Count','Total Door Egress Provided(mm)', 'Door Egress Required(mm)'])

####################################################################################################################

from rpw.ui.forms import SelectFromList
from rpw.utils.coerce import to_category 

###################################################################################################################    

userInputcategory = SelectFromList('Select Fire Code to analyse for the Building.', ['01.NBC', '02.SBC', '03.IBC', '04.NFPA', '05.DCD'])
userInputcategory = str(userInputcategory)

####################################################################################################################

if userInputcategory == '01.NBC':
    
    # Number of Exit Stairs required
    out.print_md("**OCCUPANCY ANALYSIS- BASED ON CALCULATED OCCUPANT COUNTS\n**")
    out.print_md("**TOTAL OCCUPANT COUNT FOR THE BUILDING AS PER NBC CODE IS- {} PEOPLE. **".format(total_occupant_count_for_building))
    out.print_md("**NUMBER OF EXITS REQUIRED BASED ON OCCUPANT COUNT\n**")
    idx_of_sum_range_less_than_500_NBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 500)]
    idx_of_sum_range_500_to_1000_NBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if( x <= 1000 and x > 500)]
    idx_of_sum_range_greater_than_1000_NBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x > 1000)]

    levels_with_occupancy_range_less_than_500_NBC = [unique_room_level_names[i] for i in idx_of_sum_range_less_than_500_NBC]
    levels_with_occupancy_range_500_to_1000_NBC = [unique_room_level_names[i] for i in idx_of_sum_range_500_to_1000_NBC]
    levels_with_occupancy_range_greater_than_1000_NBC =  [unique_room_level_names[i] for i in idx_of_sum_range_greater_than_1000_NBC]

    occupant_count_group_range_less_than_500_NBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_less_than_500_NBC]
    occupant_count_group_range_500_to_1000_NBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_500_to_1000_NBC]
    occupant_count_group_range_greater_than_1000_NBC =  [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_greater_than_1000_NBC]

    if len(occupant_count_group_range_less_than_500_NBC) != 0:   
        print('\nAs per NBC- minimum 2 Exit Stairs are required, from the following Levels, for Occupant count, less than 500 people.')
        output_for_no_of_exits_required_less_than_500 = output_statement_for_occupant_load(levels_with_occupancy_range_less_than_500_NBC, occupant_count_group_range_less_than_500_NBC)
    else:
        print('\nNo Levels exist, with Occupant count less than 500 people, hence no assessment as per NBC code.')
        
    if len(occupant_count_group_range_500_to_1000_NBC) != 0:       
        print('\nAs per NBC- minimum 3 Exits are required, from the following Levels, for Occupant count, greater than 500 people, but less than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_range_500_to_1000_NBC, occupant_count_group_range_500_to_1000_NBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 500 people & less than 1000 people, hence no assessment as per NBC code.")
        
    if len(occupant_count_group_range_greater_than_1000_NBC) != 0:     
        print('\nAs per NBC- minimum 4 exits is required, from the following Levels, for Occuppant count , greater than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_greater_than_1000_NBC, occupant_count_group_range_greater_than_1000_NBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 1000 people, hence no assessment as per NBC code. ")

    #################################
    # Exit Staircase Minimum Width Required
    
    print('\n ')
    print('*'*216)
    
    userInputcategory_building_type_staircase_width_assess = SelectFromList('Select Building Type-\nTotal Staircase Width Required', ['01.Residential Building','02.Residential Hotel',\
                                                                            '03.Assembly Building', '04.Educational Building- upto 30 meters', '05.Institutional Building',\
                                                                            '06.All Other Buildings', '07.All Buildings'])
    
    userInputcategory_building_type_staircase_width_assess  = str(userInputcategory_building_type_staircase_width_assess)

    if userInputcategory_building_type_staircase_width_assess  =='01.Residential Building':
        out.print_md("**Minimum width required for all staircases as per NBC for Residential Building is 1000 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  =='02.Residential Hotel':
        out.print_md("**Minimum width required for all staircases as per NBC for Residential Hotel is 1500 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  =='03.Assembly Building':
        out.print_md("**Minimum width required for all staircases as per NBC for Assembly Building is 2000 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  =='04.Educational Building- upto 30 meters':
        out.print_md("**Minimum width required for all staircases as per NBC for Educational Building- upto 30 meters, is 1500 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  =='05.Institutional Building':
        out.print_md("**Minimum width required for all staircases as per NBC for Institutional Building is 2000 mm.**")      
    elif userInputcategory_building_type_staircase_width_assess  =='06.All Other Buildings':
        out.print_md("**Minimum width required for all staircases as per NBC for Other Buildings is 1500 mm.**")
    elif userInputcategory_building_type_staircase_width_assess == '07.All Buildings':
        out.print_md("**Minimum width required for all staircases as per NBC for All Buildings is 1250 mm.**")
    else:
        pass

    print('\n ')
    print('*'*216)

    ###################################################################   
    # Egress Width for Stairway Required, for Non Sprinklered Buildings
    
    userInputcategory_building_sprinkler_chk = SelectFromList('Select Sprinklered/Non Sprinklered Building.',['01.Sprinklered', '02.Non Sprinklered'])
    userInputcategory_building_sprinkler_chk =str(userInputcategory_building_sprinkler_chk)
           
    if(userInputcategory_building_sprinkler_chk) == '02.Non Sprinklered':
    
        userInputcategory_building_without_sprinkler_exit_load_chk = SelectFromList('Select Building Type for Stairway Width Assessment.',['01.Residential','02.Educational','03.Institutional',\
                                                                                    '04.Assembly','05.Business', '06.Mercantile', '07.Industrial', '08.Storage', '09.Hazardous'])
        userInputcategory_building_without_sprinkler_exit_load_chk =str(userInputcategory_building_without_sprinkler_exit_load_chk)
     
        if userInputcategory_building_without_sprinkler_exit_load_chk == '01.Residential':
            egress_capacity_NBC_exit_stair_factor_residential = 10
            egress_capacity_reqd_exit_stair_NBC_residential = [(x * egress_capacity_NBC_exit_stair_factor_residential) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Residential Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_residential) 
        
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '02.Educational':
            egress_capacity_NBC_exit_stair_factor_educational = 10
            egress_capacity_reqd_exit_stair_NBC_educational = [(x * egress_capacity_NBC_exit_stair_factor_educational) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Educational Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_educational) 

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '03.Institutional':
            egress_capacity_NBC_exit_stair_factor_institutional = 15
            egress_capacity_reqd_exit_stair_NBC_institutional = [(x * egress_capacity_NBC_exit_stair_factor_institutional) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Institutional Building are as per follows:**')
            output_for_egress_load_no_sprinklered_institutional = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_institutional) 

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '04.Assembly':
            egress_capacity_NBC_exit_stair_factor_assembly = 10
            egress_capacity_reqd_exit_stair_NBC_assembly = [(x * egress_capacity_NBC_exit_stair_factor_assembly) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Assembly Building are as per follows:**')
            output_for_egress_load_no_sprinklered_assembly = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_assembly) 
            
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '05.Business':
            egress_capacity_NBC_exit_stair_factor_business = 10
            egress_capacity_reqd_exit_stair_NBC_business = [(x * egress_capacity_NBC_exit_stair_factor_business) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Business Building are as per follows:**')
            output_for_egress_load_no_sprinklered_business = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_business)  

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '06.Mercantile':
            egress_capacity_NBC_exit_stair_factor_mercantile = 10
            egress_capacity_reqd_exit_stair_NBC_mercantile = [(x * egress_capacity_NBC_exit_stair_factor_mercantile) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Mercantile Building are as per follows:**')
            output_for_egress_load_no_sprinklered_mercantile = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_mercantile)  
          
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '07.Industrial':
            egress_capacity_NBC_exit_stair_factor_industrial = 10
            egress_capacity_reqd_exit_stair_NBC_industrial = [(x * egress_capacity_NBC_exit_stair_factor_industrial) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Industrial Building are as per follows:**')
            output_for_egress_load_no_sprinklered_industrial = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_industrial)          

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '08.Storage':
            egress_capacity_NBC_exit_stair_factor_storage = 10
            egress_capacity_reqd_exit_stair_NBC_storage = [(x * egress_capacity_NBC_exit_stair_factor_storage) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Storage Building are as per follows:**')
            output_for_egress_load_no_sprinklered_storage = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_storage)    

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '09.Hazardous':
            egress_capacity_NBC_exit_stair_factor_hazardous = 18
            egress_capacity_reqd_exit_stair_NBC_hazardous = [(x * egress_capacity_NBC_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NBC- Stairway Egress Width Required, for the following Levels, for Hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_hazardous = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NBC_hazardous)               
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Non Sprinklered Buildings
        
#         userInputcategory_door_exit_building_without_sprinkler_chk = SelectFromList('Select Building Type- for Door Width Assessment' , ['01.Residential','02.Educational',\
#                                                                                     '03.Institutional', '04.Assembly', '05.Business', '06.Mercantile', '07.Industrial', '08.Storage', '09.Hazardous'])
#         userInputcategory_door_exit_building_without_sprinkler_chk = str(userInputcategory_door_exit_building_without_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_without_sprinkler_chk == '01.Residential':
#             egress_capacity_required_for_room_NBC_residential = egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Residential Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_residential = output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_residential)
           
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '02.Educational':
#             egress_capacity_required_for_room_NBC_educational = egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Educational Building are as per follows:**')            
#             output_for_door_egress_comparision_NBC_educational = output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_educational)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '03.Institutional':
#             egress_capacity_required_for_room_NBC_institutional = egress_capacity_factor_analysis_for_doors(13)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Institutional Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_institutional =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_institutional)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '04.Assembly':
#             egress_capacity_required_for_room_NBC_assembly = egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Assembly Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_assembly =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_assembly)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '05.Business':
#             egress_capacity_required_for_room_NBC_business = egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Business Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_business =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_business)
       
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '06.Mercantile':
#             egress_capacity_required_for_room_NBC_mercantile = egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Mercantile Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_mercantile =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_mercantile)
        
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '07.Industrial':
#             egress_capacity_required_for_room_NBC_industrial= egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Industrial Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_industrial =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_industrial)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '08.Storage':
#             egress_capacity_required_for_room_NBC_storage= egress_capacity_factor_analysis_for_doors(6.5)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Storage Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_storage =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_storage)       

#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '09.Hazardous':
#             egress_capacity_required_for_room_NBC_hazardous= egress_capacity_factor_analysis_for_doors(10)
#             out.print_md('**As per NBC- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')
#             output_for_door_egress_comparision_NBC_hazardous =  output_statement_for_egress_comparision(egress_capacity_required_for_room_NBC_hazardous)       
                
#         else:
#             pass 
        
    # Sprinklered
    
    elif(userInputcategory_building_sprinkler_chk) == '01.Sprinklered':
        out.print_md("No Data found for Sprinklered Building, as per NBC Code.")
        
    else:
        pass    

# ######################################################################################################################

elif userInputcategory == '02.SBC':
    
    # Number of Exit Stairs required
    out.print_md("**OCCUPANCY ANALYSIS- BASED ON CALCULATED OCCUPANT COUNTS\n**")
    out.print_md("**TOTAL OCCUPANT COUNT FOR THE BUILDING AS PER SBC CODE IS- {} PEOPLE. **".format(total_occupant_count_for_building))
    out.print_md("**NUMBER OF EXITS REQUIRED BASED ON OCCUPANT COUNT\n**")
    
    idx_of_sum_range_less_than_10_SBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 10)]
    idx_of_sum_range_10_to_500_SBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 500 and x > 10)]
    idx_of_sum_range_500_to_1000_SBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if( x <= 1000 and x > 500)]
    idx_of_sum_range_greater_than_1000_SBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x > 1000)]

    levels_with_occupancy_range_less_than_10_SBC = [unique_room_level_names[i] for i in idx_of_sum_range_less_than_10_SBC]
    levels_with_occupancy_range_10_to_500_SBC = [unique_room_level_names[i] for i in idx_of_sum_range_10_to_500_SBC]
    levels_with_occupancy_range_500_to_1000_SBC = [unique_room_level_names[i] for i in idx_of_sum_range_500_to_1000_SBC]
    levels_with_occupancy_range_greater_than_1000_SBC = [unique_room_level_names[i] for i in idx_of_sum_range_greater_than_1000_SBC]

    occupant_count_group_range_less_than_10_SBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_less_than_10_SBC]
    occupant_count_group_range_10_to_500_SBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_10_to_500_SBC]
    occupant_count_group_range_500_to_1000_SBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_500_to_1000_SBC]
    occupant_count_group_range_greater_than_1000_SBC =  [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_greater_than_1000_SBC]

    if len(occupant_count_group_range_less_than_10_SBC) != 0:   
        print('\nAs per SBC- minimum 1 Exit Stair is required, from the following Levels, for Occupant count, less than 10 people.')
        output_for_no_of_exits_required_less_than_10 = output_statement_for_occupant_load(levels_with_occupancy_range_less_than_10_SBC, occupant_count_group_range_less_than_10_SBC)
    else:
        print('\nNo Levels exist, with Occupant count less than 10 people, hence no assessment as per SBC code.')

    if len(occupant_count_group_range_10_to_500_SBC) != 0:   
        print('\nAs per SBC- minimum 2 Exit Stairs are required, from the following Levels, for Occupant count, greater than 10 people, but less than 500 people.')
        output_for_no_of_exits_required_less_than_500 = output_statement_for_occupant_load(levels_with_occupancy_range_10_to_500_SBC, occupant_count_group_range_10_to_500_SBC)
    else:
        print('\nNo Levels exist, with Occupant count greater than 10 people, but less than 500 people, hence no assessment as per SBC code.')
        
    if len(occupant_count_group_range_500_to_1000_SBC) != 0:       
        print('\nAs per SBC- minimum 3 Exits are required, from the following Levels, for Occupant count, greater than 500 people, but less than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_range_500_to_1000_SBC, occupant_count_group_range_500_to_1000_SBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 500 people & less than 1000 people, hence no assessment as per SBC code.")
        
    if len(occupant_count_group_range_greater_than_1000_SBC) != 0:     
        print('\nAs per SBC- minimum 4 exits is required, from the following Levels, for Occuppant count , greater than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_greater_than_1000_SBC, occupant_count_group_range_greater_than_1000_SBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 1000 people, hence no assessment as per SBC code. ")

    #######################################
    # Exit Staircase Minimum Width Required
    
    print('\n ')
    print('*'*216)
 

    userInputcategory_building_type_staircase_width_assess = SelectFromList('Select Building Type-\nTotal Staircase Width Required', ['01.All Buildings with Occupancy < 50 people',\
                                                                                                                                      '02.All Buildings with Occupancy > 50 people'])
    
    userInputcategory_building_type_staircase_width_assess  = str(userInputcategory_building_type_staircase_width_assess)

    if userInputcategory_building_type_staircase_width_assess  == '01.All Buildings with Occupancy < 50 people':
        out.print_md("**Minimum width required for all staircases as per SBC for Residential Building is 910 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  == '02.All Buildings with Occupancy > 50 people':
        out.print_md("**Minimum width required for all staircases as per SBC for Residential Hotel is 1120 mm.**")
    else:
        pass
    print('\n ')
    print('*'*216)

    ###################################################################   
    # Egress Width for Stairway Required, for Non Sprinklered Buildings
    
    userInputcategory_building_sprinkler_chk = SelectFromList('Select Sprinklered/Non Sprinklered Building.',['01.Sprinklered', '02.Non Sprinklered'])
    userInputcategory_building_sprinkler_chk =str(userInputcategory_building_sprinkler_chk)
           
    if(userInputcategory_building_sprinkler_chk) == '02.Non Sprinklered':
  
        userInputcategory_building_without_sprinkler_exit_load_chk = SelectFromList('Select Non Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings',\
                                                                                                                                                            '02.Hazardous-H-1,H-2,H-3 and H-4'])
        userInputcategory_building_without_sprinkler_exit_load_chk =str(userInputcategory_building_without_sprinkler_exit_load_chk)
     
        if userInputcategory_building_without_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_SBC_exit_stair_factor_all_other_buildings = 7.6
            egress_capacity_reqd_exit_stair_SBC_all_other_buildings = [(x * egress_capacity_SBC_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per SBC- Stairway Egress Width Required, for the following Levels, for All Other Buildings are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_SBC_all_other_buildings) 
        
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
            egress_capacity_SBC_exit_stair_factor_hazardous = 17.8
            egress_capacity_reqd_exit_stair_SBC_hazardous = [(x * egress_capacity_SBC_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per SBC- Stairway Egress Width Required, for the following Levels, for Hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_hazardous = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_SBC_hazardous) 
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Non Sprinklered Buildings
        
#         userInputcategory_door_exit_building_without_sprinkler_chk = SelectFromList('Select Non Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.All other Buildings',\
#                                                                                                                                                             '02.Hazardous-H-1,H-2,H-3 and H-4']) 
                                                                                    
#         userInputcategory_door_exit_building_without_sprinkler_chk = str(userInputcategory_door_exit_building_without_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_without_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_SBC_all_other_buildings = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per SBC- Door Egress Width Required, for the following Rooms, for All Other Buildings Buildings are as per follows:**')
#             output_for_door_egress_comparision_SBC_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_SBC_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
#             egress_capacity_required_for_room_SBC_hazardous = egress_capacity_factor_analysis_for_doors(10.2)
#             out.print_md('**As per SBC- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')            
#             output_for_door_egress_comparision_SBC_hazardous = output_statement_for_egress_comparision(egress_capacity_required_for_room_SBC_hazardous)
#         else:
#             pass 
        
    # Sprinklered
    
    ###################################################################   
    # Egress Width for Stairway Required, for Sprinklered Buildings
    
    
    elif(userInputcategory_building_sprinkler_chk) == '01.Sprinklered':
        userInputcategory_building_with_sprinkler_exit_load_chk = SelectFromList('Select Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings','02.Hazardous-H-1,H-2,H-3 and H-4',\
                                                                                '03.Institutional - I-2'])
        userInputcategory_building_with_sprinkler_exit_load_chk =str(userInputcategory_building_with_sprinkler_exit_load_chk)

     
        if userInputcategory_building_with_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_SBC_exit_stair_factor_all_other_buildings = 5
            egress_capacity_reqd_exit_stair_SBC_all_other_buildings = [(x * egress_capacity_SBC_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per SBC- Stairway Egress Width Required, for the following Levels, for all_other_buildings Building are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_SBC_all_other_buildings) 
        
        elif userInputcategory_building_with_sprinkler_exit_load_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
            egress_capacity_SBC_exit_stair_factor_hazardous = 7.6
            egress_capacity_reqd_exit_stair_SBC_hazardous = [(x * egress_capacity_SBC_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per SBC- Stairway Egress Width Required, for the following Levels, for hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_SBC_hazardous) 
        
        elif userInputcategory_building_with_sprinkler_exit_load_chk == '03.Institutional - I-2':
            egress_capacity_SBC_exit_stair_factor_institutional = 7.6
            egress_capacity_reqd_exit_stair_SBC_institutional = [(x * egress_capacity_SBC_exit_stair_factor_institutional) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per SBC- Stairway Egress Width Required, for the following Levels, for Institutional Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_SBC_institutional) 
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Sprinklered Buildings
        
#         userInputcategory_door_exit_building_with_sprinkler_chk = SelectFromList('Select Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.All other Buildings','02.Hazardous-H-1,H-2,H-3 and H-4',\
#                                                                                                                                                             '03.Institutional - I-2']) 
#         userInputcategory_door_exit_building_with_sprinkler_chk = str(userInputcategory_door_exit_building_with_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_with_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_SBC_all_other_buildings = egress_capacity_factor_analysis_for_doors(3.8)
#             out.print_md('**As per SBC- Door Egress Width Required, for the following Rooms, for All Other Buildings Buildings are as per follows:**')
#             output_for_door_egress_comparision_SBC_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_SBC_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_with_sprinkler_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
#             egress_capacity_required_for_room_SBC_hazardous = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per SBC- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')            
#             output_for_door_egress_comparision_SBC_hazardous = output_statement_for_egress_comparision(egress_capacity_required_for_room_SBC_hazardous)
       
#         elif userInputcategory_door_exit_building_with_sprinkler_chk == '03.Institutional - I-2':
#             egress_capacity_required_for_room_SBC_institutional = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per SBC- Door Egress Width Required, for the following Rooms, for Institutional Building are as per follows:**')            
#             output_for_door_egress_comparision_SBC_institutional = output_statement_for_egress_comparision(egress_capacity_required_for_room_SBC_institutional)      
       
#         else:
#             pass 
        
 
######################################################################################################################   
elif userInputcategory == '03.IBC':
    
    # Number of Exit Stairs required
    out.print_md("**OCCUPANCY ANALYSIS- BASED ON CALCULATED OCCUPANT COUNTS\n**")
    out.print_md("**TOTAL OCCUPANT COUNT FOR THE BUILDING AS PER IBC CODE IS- {} PEOPLE. **".format(total_occupant_count_for_building))
    out.print_md("**NUMBER OF EXITS REQUIRED BASED ON OCCUPANT COUNT\n**")
    idx_of_sum_range_less_than_500_IBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 500)]
    idx_of_sum_range_500_to_1000_IBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if( x <= 1000 and x > 500)]
    idx_of_sum_range_greater_than_1000_IBC = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x > 1000)]

    levels_with_occupancy_range_less_than_500_IBC = [unique_room_level_names[i] for i in idx_of_sum_range_less_than_500_IBC]
    levels_with_occupancy_range_500_to_1000_IBC = [unique_room_level_names[i] for i in idx_of_sum_range_500_to_1000_IBC]
    levels_with_occupancy_range_greater_than_1000_IBC =  [unique_room_level_names[i] for i in idx_of_sum_range_greater_than_1000_IBC]

    occupant_count_group_range_less_than_500_IBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_less_than_500_IBC]
    occupant_count_group_range_500_to_1000_IBC = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_500_to_1000_IBC]
    occupant_count_group_range_greater_than_1000_IBC =  [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_greater_than_1000_IBC]

    if len(occupant_count_group_range_less_than_500_IBC) != 0:   
        print('\nAs per IBC- minimum 2 Exit Stairs are required, from the following Levels, for Occupant count, less than 500 people.')
        output_for_no_of_exits_required_less_than_500 = output_statement_for_occupant_load(levels_with_occupancy_range_less_than_500_IBC, occupant_count_group_range_less_than_500_IBC)
    else:
        print('\nNo Levels exist, with Occupant count less than 500 people, hence no assessment as per IBC code.')
        
    if len(occupant_count_group_range_500_to_1000_IBC) != 0:       
        print('\nAs per IBC- minimum 3 Exits are required, from the following Levels, for Occupant count, greater than 500 people, but less than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_range_500_to_1000_IBC, occupant_count_group_range_500_to_1000_IBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 500 people & less than 1000 people, hence no assessment as per IBC code.")
        
    if len(occupant_count_group_range_greater_than_1000_IBC) != 0:     
        print('\nAs per IBC- minimum 4 exits is required, from the following Levels, for Occuppant count , greater than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_greater_than_1000_IBC, occupant_count_group_range_greater_than_1000_IBC)
    else:
        print("\nNo Levels exist, with Occupant count greater than 1000 people, hence no assessment as per IBC code.")


    #######################################
    # Exit Staircase Minimum Width Required
    
    print('\n ')
    print('*'*216)
 

    userInputcategory_building_type_staircase_width_assess = SelectFromList('Select Building Type-\nTotal Staircase Width Required', ['01.All Buildings with Occupancy < 50 people',\
                                                                                                                                      '02.All Buildings with Occupancy > 50 people'])
    
    userInputcategory_building_type_staircase_width_assess  = str(userInputcategory_building_type_staircase_width_assess)

    if userInputcategory_building_type_staircase_width_assess  == '01.All Buildings with Occupancy < 50 people':
        out.print_md("**Minimum width required for all staircases as per IBC for Residential Building is 914 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  == '02.All Buildings with Occupancy > 50 people':
        out.print_md("**Minimum width required for all staircases as per IBC for Residential Hotel is 1118 mm.**")
    else:
        pass
    print('\n ')
    print('*'*216)

    ###################################################################
    # Egress Width for Stairway Required, for Non Sprinklered Buildings
    
    userInputcategory_building_sprinkler_chk = SelectFromList('Select Sprinklered/Non Sprinklered Building.',['01.Sprinklered', '02.Non Sprinklered'])
    userInputcategory_building_sprinkler_chk =str(userInputcategory_building_sprinkler_chk)
           
    if(userInputcategory_building_sprinkler_chk) == '02.Non Sprinklered':
  
        userInputcategory_building_without_sprinkler_exit_load_chk = SelectFromList('Select Non Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings',\
                                                                                                                                                            '02.Hazardous-H-1,H-2,H-3 and H-4'])
        userInputcategory_building_without_sprinkler_exit_load_chk =str(userInputcategory_building_without_sprinkler_exit_load_chk)
     
        if userInputcategory_building_without_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_IBC_exit_stair_factor_all_other_buildings = 7.6
            egress_capacity_reqd_exit_stair_IBC_all_other_buildings = [(x * egress_capacity_IBC_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per IBC- Stairway Egress Width Required, for the following Levels, for All Other Buildings are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_IBC_all_other_buildings) 
        
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
            egress_capacity_IBC_exit_stair_factor_hazardous = 17.78
            egress_capacity_reqd_exit_stair_IBC_hazardous = [(x * egress_capacity_IBC_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per IBC- Stairway Egress Width Required, for the following Levels, for Hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_hazardous = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_IBC_hazardous) 
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Non Sprinklered Buildings
        
#         userInputcategory_door_exit_building_without_sprinkler_chk = SelectFromList('Select Non Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.All other Buildings',\
#                                                                                                                                                             '02.Hazardous-H-1,H-2,H-3 and H-4']) 
                                                                                    
#         userInputcategory_door_exit_building_without_sprinkler_chk = str(userInputcategory_door_exit_building_without_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_without_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_IBC_all_other_buildings = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per IBC- Door Egress Width Required, for the following Rooms, for All Other Buildings are as per follows:**')
#             output_for_door_egress_comparision_IBC_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_IBC_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
#             egress_capacity_required_for_room_IBC_hazardous = egress_capacity_factor_analysis_for_doors(10.16)
#             out.print_md('**As per IBC- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')            
#             output_for_door_egress_comparision_IBC_hazardous = output_statement_for_egress_comparision(egress_capacity_required_for_room_IBC_hazardous)
#         else:
#             pass 
        
    # Sprinklered
    
    ###################################################################   
    # Egress Width for Stairway Required, for Sprinklered Buildings
    
    
    elif(userInputcategory_building_sprinkler_chk) == '01.Sprinklered':
        userInputcategory_building_with_sprinkler_exit_load_chk = SelectFromList('Select Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings','02.Hazardous-H-1,H-2,H-3 and H-4',\
                                                                                '03.Institutional - I-2'])
        userInputcategory_building_with_sprinkler_exit_load_chk =str(userInputcategory_building_with_sprinkler_exit_load_chk)

     
        if userInputcategory_building_with_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_IBC_exit_stair_factor_all_other_buildings = 5
            egress_capacity_reqd_exit_stair_IBC_all_other_buildings = [(x * egress_capacity_IBC_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per IBC- Stairway Egress Width Required, for the following Levels, for All Other Buildings are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_IBC_all_other_buildings) 
        
        elif userInputcategory_building_with_sprinkler_exit_load_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
            egress_capacity_IBC_exit_stair_factor_hazardous = 7.6
            egress_capacity_reqd_exit_stair_IBC_hazardous = [(x * egress_capacity_IBC_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per IBC- Stairway Egress Width Required, for the following Levels, for Hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_IBC_hazardous) 
        
        elif userInputcategory_building_with_sprinkler_exit_load_chk == '03.Institutional - I-2':
            egress_capacity_IBC_exit_stair_factor_institutional = 7.6
            egress_capacity_reqd_exit_stair_IBC_institutional = [(x * egress_capacity_IBC_exit_stair_factor_institutional) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per IBC- Stairway Egress Width Required, for the following Levels, for Institutional Building are as per follows:**')
            output_for_egress_load_no_sprinklered_residential = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_IBC_institutional) 
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Sprinklered Buildings
        
#         userInputcategory_door_exit_building_with_sprinkler_chk = SelectFromList('Select Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.All other Buildings','02.Hazardous-H-1,H-2,H-3 and H-4',\
#                                                                                                                                                             '03.Institutional - I-2']) 
#         userInputcategory_door_exit_building_with_sprinkler_chk = str(userInputcategory_door_exit_building_with_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_with_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_IBC_all_other_buildings = egress_capacity_factor_analysis_for_doors(3.8)
#             out.print_md('**As per IBC- Door Egress Width Required, for the following Rooms, for All Other Buildings Buildings are as per follows:**')
#             output_for_door_egress_comparision_IBC_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_IBC_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_with_sprinkler_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
#             egress_capacity_required_for_room_IBC_hazardous = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per IBC- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')            
#             output_for_door_egress_comparision_IBC_hazardous = output_statement_for_egress_comparision(egress_capacity_required_for_room_IBC_hazardous)
       
#         elif userInputcategory_door_exit_building_with_sprinkler_chk == '03.Institutional - I-2':
#             egress_capacity_required_for_room_IBC_institutional = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per IBC- Door Egress Width Required, for the following Rooms, for Institutional Building are as per follows:**')            
#             output_for_door_egress_comparision_IBC_institutional = output_statement_for_egress_comparision(egress_capacity_required_for_room_IBC_institutional)      
       
#         else:
#             pass 

#####################################################################################################################
elif userInputcategory == '04.NFPA':

    # Number of Exit Stairs required
    out.print_md("**OCCUPANCY ANALYSIS- BASED ON CALCULATED OCCUPANT COUNTS\n**")
    out.print_md("**TOTAL OCCUPANT COUNT FOR THE BUILDING AS PER NFPA CODE IS- {} PEOPLE. **".format(total_occupant_count_for_building))
    out.print_md("**NUMBER OF EXITS REQUIRED BASED ON OCCUPANT COUNT\n**")
    idx_of_sum_range_less_than_500_NFPA = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 500)]
    idx_of_sum_range_500_to_1000_NFPA = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if( x <= 1000 and x > 500)]
    idx_of_sum_range_greater_than_1000_NFPA = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x > 1000)]

    levels_with_occupancy_range_less_than_500_NFPA = [unique_room_level_names[i] for i in idx_of_sum_range_less_than_500_NFPA]
    levels_with_occupancy_range_500_to_1000_NFPA = [unique_room_level_names[i] for i in idx_of_sum_range_500_to_1000_NFPA]
    levels_with_occupancy_range_greater_than_1000_NFPA =  [unique_room_level_names[i] for i in idx_of_sum_range_greater_than_1000_NFPA]

    occupant_count_group_range_less_than_500_NFPA = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_less_than_500_NFPA]
    occupant_count_group_range_500_to_1000_NFPA = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_500_to_1000_NFPA]
    occupant_count_group_range_greater_than_1000_NFPA =  [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_greater_than_1000_NFPA]

    if len(occupant_count_group_range_less_than_500_NFPA) != 0:   
        print('\nAs per NFPA- minimum 2 Exit Stairs are required, from the following Levels, for Occupant count, less than 500 people.')
        output_for_no_of_exits_required_less_than_500 = output_statement_for_occupant_load(levels_with_occupancy_range_less_than_500_NFPA, occupant_count_group_range_less_than_500_NFPA)
    else:
        print('\nNo Levels exist, with Occupant count less than 500 people, hence no assessment as per NFPA code.')
        
    if len(occupant_count_group_range_500_to_1000_NFPA) != 0:       
        print('\nAs per NFPA- minimum 3 Exits are required, from the following Levels, for Occupant count, greater than 500 people, but less than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_range_500_to_1000_NFPA, occupant_count_group_range_500_to_1000_NFPA)
    else:
        print("\nNo Levels exist, with Occupant count greater than 500 people & less than 1000 people, hence no assessment as per NFPA code.")
        
    if len(occupant_count_group_range_greater_than_1000_NFPA) != 0:     
        print('\nAs per NFPA- minimum 4 exits is required, from the following Levels, for Occuppant count , greater than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_greater_than_1000_NFPA, occupant_count_group_range_greater_than_1000_NFPA)
    else:
        print("\nNo Levels exist, with Occupant count greater than 1000 people, hence no assessment as per NFPA code.")

    #######################################
    # Exit Staircase Minimum Width Required
    
    print('\n ')
    print('*'*216)
 

    userInputcategory_building_type_staircase_width_assess = SelectFromList('Select Building Type-\nTotal Staircase Width Required', ['01.All Buildings with Occupancy < 2000 people',\
                                                                                                                                      '02.All Buildings with Occupancy > 2000 people'])
    
    userInputcategory_building_type_staircase_width_assess  = str(userInputcategory_building_type_staircase_width_assess)

    if userInputcategory_building_type_staircase_width_assess  == '01.All Buildings with Occupancy < 2000 people':
        out.print_md("**Minimum width required for all staircases as per NFPA for Residential Building is 1120 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  == '02.All Buildings with Occupancy > 2000 people':
        out.print_md("**Minimum width required for all staircases as per NFPA for Residential Hotel is 1420 mm.**")
    else:
        pass
    print('\n ')
    print('*'*216)

    ###################################################################
    # Egress Width for Stairway Required, for Non Sprinklered Buildings
    
    userInputcategory_building_sprinkler_chk = SelectFromList('Select Sprinklered/Non Sprinklered Building.',['01.Sprinklered', '02.Non Sprinklered'])
    userInputcategory_building_sprinkler_chk =str(userInputcategory_building_sprinkler_chk)
           
    if(userInputcategory_building_sprinkler_chk) == '02.Non Sprinklered':
  
        userInputcategory_building_without_sprinkler_exit_load_chk = SelectFromList('Select Non Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings',\
                                                                                                                                                            '02.Hazardous-H-1,H-2,H-3 and H-4',\
                                                                                                                                                            '03.Board and Care', '04.Healthcare'])
        userInputcategory_building_without_sprinkler_exit_load_chk =str(userInputcategory_building_without_sprinkler_exit_load_chk)
     
        if userInputcategory_building_without_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_NFPA_exit_stair_factor_all_other_buildings = 7.6
            egress_capacity_reqd_exit_stair_NFPA_all_other_buildings = [(x * egress_capacity_NFPA_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NFPA- Stairway Egress Width Required, for the following Levels, for All Other Buildings are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NFPA_all_other_buildings) 
        
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
            egress_capacity_NFPA_exit_stair_factor_hazardous = 18
            egress_capacity_reqd_exit_stair_NFPA_hazardous = [(x * egress_capacity_NFPA_exit_stair_factor_hazardous) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NFPA- Stairway Egress Width Required, for the following Levels, for Hazardous Building are as per follows:**')
            output_for_egress_load_no_sprinklered_hazardous = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NFPA_hazardous)

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '03.Board and Care':
            egress_capacity_NFPA_exit_stair_factor_board_and_care = 10
            egress_capacity_reqd_exit_stair_NFPA_board_and_care = [(x * egress_capacity_NFPA_exit_stair_factor_board_and_care) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NFPA- Stairway Egress Width Required, for the following Levels, for Board and Care Building are as per follows:**')
            output_for_egress_load_no_sprinklered_board_and_care = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NFPA_board_and_care)
        

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '04.Healthcare':
            egress_capacity_NFPA_exit_stair_factor_healthcare = 15
            egress_capacity_reqd_exit_stair_NFPA_healthcare = [(x * egress_capacity_NFPA_exit_stair_factor_healthcare) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NFPA- Stairway Egress Width Required, for the following Levels, for Healthcare Building are as per follows:**')
            output_for_egress_load_no_sprinklered_healthcare = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NFPA_healthcare)

        else:
            pass

        ################################################################### 
#         # Egress Width of Doors Required, for Non Sprinklered Buildings
        
#         userInputcategory_door_exit_building_without_sprinkler_chk = SelectFromList('Select Non Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.All other Buildings',\
#                                                                                                                                                             '02.Hazardous-H-1,H-2,H-3 and H-4',\
#                                                                                                                                                             '03.Board and Care', '04.Healthcare']) 
                                                                                    
#         userInputcategory_door_exit_building_without_sprinkler_chk = str(userInputcategory_door_exit_building_without_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_without_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_NFPA_all_other_buildings = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per NFPA- Door Egress Width Required, for the following Rooms, for All Other Buildings are as per follows:**')
#             output_for_door_egress_comparision_NFPA_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_NFPA_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '02.Hazardous-H-1,H-2,H-3 and H-4':
#             egress_capacity_required_for_room_NFPA_hazardous = egress_capacity_factor_analysis_for_doors(10)
#             out.print_md('**As per NFPA- Door Egress Width Required, for the following Rooms, for Hazardous Building are as per follows:**')            
#             output_for_door_egress_comparision_NFPA_hazardous = output_statement_for_egress_comparision(egress_capacity_required_for_room_NFPA_hazardous)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '03.Board and Care':
#             egress_capacity_required_for_room_NFPA_board_and_care = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per NFPA- Door Egress Width Required, for the following Rooms, for Board and Care Building are as per follows:**')            
#             output_for_door_egress_comparision_NFPA_board_and_care = output_statement_for_egress_comparision(egress_capacity_required_for_room_NFPA_board_and_care)

#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '04.Healthcare':
#             egress_capacity_required_for_room_NFPA_healthcare = egress_capacity_factor_analysis_for_doors(13)
#             out.print_md('**As per NFPA- Door Egress Width Required, for the following Rooms, for Healthcare Building are as per follows:**')            
#             output_for_door_egress_comparision_NFPA_healthcare = output_statement_for_egress_comparision(egress_capacity_required_for_room_NFPA_healthcare)           
            
#         else:
#             pass 
      
    # Sprinklered
    
    ###################################################################   
    # Egress Width for Stairway Required, for Sprinklered Buildings
    
    
    elif(userInputcategory_building_sprinkler_chk) == '01.Sprinklered':
        userInputcategory_building_with_sprinkler_exit_load_chk = SelectFromList('Select Sprinklered Building Type- for Staircase Width Assessment.',['01.Healthcare'])
        userInputcategory_building_with_sprinkler_exit_load_chk =str(userInputcategory_building_with_sprinkler_exit_load_chk)

     
        if userInputcategory_building_with_sprinkler_exit_load_chk == '01.Healthcare':
            egress_capacity_NFPA_exit_stair_factor_healthcare = 7.6
            egress_capacity_reqd_exit_stair_NFPA_healthcare = [(x * egress_capacity_NFPA_exit_stair_factor_healthcare) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per NFPA- Stairway Egress Width Required, for the following Levels, for Healthcare Building are as per follows:**')
            output_for_egress_load_no_sprinklered_healthcare = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_NFPA_healthcare) 
        
        else:
            pass
        
        ################################################################### 
#         # Egress Width of Doors Required, for Sprinklered Buildings
        
#         userInputcategory_door_exit_building_with_sprinkler_chk = SelectFromList('Select Sprinklered Building Type- for Door Egress Width Assessment.' ,['01.Healthcare']) 
#         userInputcategory_door_exit_building_with_sprinkler_chk = str(userInputcategory_door_exit_building_with_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_with_sprinkler_chk == '01.Healthcare':
#             egress_capacity_required_for_room_NFPA_healthcare = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per NFPA- Door Egress Width Required, for the following Rooms, for Healthcare Building are as per follows:**')
#             output_for_door_egress_comparision_NFPA_healthcare = output_statement_for_egress_comparision(egress_capacity_required_for_room_NFPA_healthcare)

#         else:
#             pass 
 
######################################################################################################################
elif userInputcategory == '05.DCD':

    # Number of Exit Stairs required
    out.print_md("**OCCUPANCY ANALYSIS- BASED ON CALCULATED OCCUPANT COUNTS\n**")
    out.print_md("**TOTAL OCCUPANT COUNT FOR THE BUILDING AS PER DCD CODE IS- {} PEOPLE. **".format(total_occupant_count_for_building))
    out.print_md("**NUMBER OF EXITS REQUIRED BASED ON OCCUPANT COUNT\n**")
    idx_of_sum_range_less_than_500_DCD = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x <= 500)]
    idx_of_sum_range_500_to_1000_DCD = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if( x <= 1000 and x > 500)]
    idx_of_sum_range_greater_than_1000_DCD = [i for i, x in enumerate(sum_of_occupancy_count_for_each_level) if(x > 1000)]

    levels_with_occupancy_range_less_than_500_DCD = [unique_room_level_names[i] for i in idx_of_sum_range_less_than_500_DCD]
    levels_with_occupancy_range_500_to_1000_DCD = [unique_room_level_names[i] for i in idx_of_sum_range_500_to_1000_DCD]
    levels_with_occupancy_range_greater_than_1000_DCD =  [unique_room_level_names[i] for i in idx_of_sum_range_greater_than_1000_DCD]

    occupant_count_group_range_less_than_500_DCD = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_less_than_500_DCD]
    occupant_count_group_range_500_to_1000_DCD = [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_500_to_1000_DCD]
    occupant_count_group_range_greater_than_1000_DCD =  [sum_of_occupancy_count_for_each_level[i] for i in idx_of_sum_range_greater_than_1000_DCD]

    if len(occupant_count_group_range_less_than_500_DCD) != 0:   
        print('\nAs per DCD- minimum 2 Exit Stairs are required, from the following Levels, for Occupant count, less than 500 people.')
        output_for_no_of_exits_required_less_than_500 = output_statement_for_occupant_load(levels_with_occupancy_range_less_than_500_DCD, occupant_count_group_range_less_than_500_DCD)
    else:
        print('\nNo Levels exist, with Occupant count less than 500 people, hence no assessment as per DCD code.')
        
    if len(occupant_count_group_range_500_to_1000_DCD) != 0:       
        print('\nAs per DCD- minimum 3 Exits are required, from the following Levels, for Occupant count, greater than 500 people, but less than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_range_500_to_1000_DCD, occupant_count_group_range_500_to_1000_DCD)
    else:
        print("\nNo Levels exist, with Occupant count greater than 500 people & less than 1000 people, hence no assessment as per DCD code.")
        
    if len(occupant_count_group_range_greater_than_1000_DCD) != 0:     
        print('\nAs per DCD- minimum 4 exits is required, from the following Levels, for Occuppant count , greater than 1000 people.')
        output_for_no_of_exits_required_500_1000 = output_statement_for_occupant_load(levels_with_occupancy_greater_than_1000_DCD, occupant_count_group_range_greater_than_1000_DCD)
    else:
        print("\nNo Levels exist, with Occupant count greater than 1000 people, hence no assessment as per DCD code.")

    #######################################
    # Exit Staircase Minimum Width Required
    
    print('\n ')
    print('*'*216)
 
    userInputcategory_building_type_staircase_width_assess = SelectFromList('Select Building Type-\nTotal Staircase Width Required', ['01.All Buildings with Occupancy < 2000 people',\
                                                                                                                                      '02.All Buildings with Occupancy > 2000 people'])
   
    userInputcategory_building_type_staircase_width_assess  = str(userInputcategory_building_type_staircase_width_assess)

    if userInputcategory_building_type_staircase_width_assess  == '01.All Buildings with Occupancy < 2000 people':
        out.print_md("**Minimum width required for all staircases as per DCD for Residential Building is 1200 mm.**")
    elif userInputcategory_building_type_staircase_width_assess  == '02.All Buildings with Occupancy > 2000 people':
        out.print_md("**Minimum width required for all staircases as per DCD for Residential Hotel is 1420 mm.**")
    else:
        pass
    print('\n ')
    print('*'*216)

    ###################################################################
    # Egress Width for Stairway Required, for Non Sprinklered Buildings
    
    userInputcategory_building_sprinkler_chk = SelectFromList('Select Sprinklered/Non Sprinklered Building.',['01.Sprinklered', '02.Non Sprinklered'])
    userInputcategory_building_sprinkler_chk =str(userInputcategory_building_sprinkler_chk)
           
    if(userInputcategory_building_sprinkler_chk) == '02.Non Sprinklered':
        
        userInputcategory_building_without_sprinkler_exit_load_chk = SelectFromList('Select Non Sprinklered Building Type- for Staircase Width Assessment.',['01.All other Buildings',\
                                                                                                                                                            '02.High Hazard Storage',\
                                                                                                                                                            '03.Industrial High Hazard', '04.Day Care'])
        userInputcategory_building_without_sprinkler_exit_load_chk =str(userInputcategory_building_without_sprinkler_exit_load_chk)
     
        if userInputcategory_building_without_sprinkler_exit_load_chk == '01.All other Buildings':
            egress_capacity_DCD_exit_stair_factor_all_other_buildings = 7.6
            egress_capacity_reqd_exit_stair_DCD_all_other_buildings = [(x * egress_capacity_DCD_exit_stair_factor_all_other_buildings) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per DCD- Stairway Egress Width Required, for the following Levels, for All Other Buildings are as per follows:**')
            output_for_egress_load_no_sprinklered_all_other_buildings = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_DCD_all_other_buildings) 
        
        elif userInputcategory_building_without_sprinkler_exit_load_chk == '02.High Hazard Storage':
            egress_capacity_DCD_exit_stair_factor_high_hazard_storage = 18
            egress_capacity_reqd_exit_stair_DCD_high_hazard_storage = [(x * egress_capacity_DCD_exit_stair_factor_high_hazard_storage) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per DCD- Stairway Egress Width Required, for the following Levels, for High Hazard Storage Building are as per follows:**')
            output_for_egress_load_no_sprinklered_high_hazard_storage = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_DCD_high_hazard_storage)

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '03.Industrial High Hazard':
            egress_capacity_DCD_exit_stair_factor_industrial_high_hazard = 18
            egress_capacity_reqd_exit_stair_DCD_industrial_high_hazard = [(x * egress_capacity_DCD_exit_stair_factor_industrial_high_hazard) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per DCD- Stairway Egress Width Required, for the following Levels, for Industrial High Hazard Building are as per follows:**')
            output_for_egress_load_no_sprinklered_industrial_high_hazard = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_DCD_industrial_high_hazard)
        

        elif userInputcategory_building_without_sprinkler_exit_load_chk == '04.Day Care':
            egress_capacity_DCD_exit_stair_factor_day_care = 10
            egress_capacity_reqd_exit_stair_DCD_day_care = [(x * egress_capacity_DCD_exit_stair_factor_day_care) for x  in sum_of_occupancy_count_for_each_level]
            out.print_md('**As per DCD- Stairway Egress Width Required, for the following Levels, for Day Care Building are as per follows:**')
            output_for_egress_load_no_sprinklered_day_care = output_statement_for_egress_load(unique_room_level_names, sum_of_occupancy_count_for_each_level,\
                                                                                                 egress_capacity_reqd_exit_stair_DCD_day_care)

        else:
            pass

        ################################################################### 
#         # Egress Width of Doors Required, for Non Sprinklered Buildings
        
#         userInputcategory_door_exit_building_without_sprinkler_chk = SelectFromList('Select Non Sprinklered Building Type- for Door Egress Width Assessment.',['01.All other Buildings',\
#                                                                                                                                                                '02.High Hazard Storage',\
#                                                                                                                                                                '03.Industrial High Hazard', '04.Day Care'])
#         userInputcategory_door_exit_building_without_sprinkler_chk = str(userInputcategory_door_exit_building_without_sprinkler_chk)
    
#         print('\n ')
#         print('*'*216)
      
#         if userInputcategory_door_exit_building_without_sprinkler_chk == '01.All other Buildings':
#             egress_capacity_required_for_room_DCD_all_other_buildings = egress_capacity_factor_analysis_for_doors(5)
#             out.print_md('**As per DCD- Door Egress Width Required, for the following Rooms, for All Other Buildings are as per follows:**')
#             output_for_door_egress_comparision_DCD_all_other_buildings = output_statement_for_egress_comparision(egress_capacity_required_for_room_DCD_all_other_buildings)
           
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '02.High Hazard Storage':
#             egress_capacity_required_for_room_DCD_high_hazard_storage = egress_capacity_factor_analysis_for_doors(10)
#             out.print_md('**As per DCD- Door Egress Width Required, for the following Rooms, for High Hazard Storage Building are as per follows:**')            
#             output_for_door_egress_comparision_DCD_high_hazard_storage = output_statement_for_egress_comparision(egress_capacity_required_for_room_DCD_high_hazard_storage)
            
#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '03.Industrial High Hazard':
#             egress_capacity_required_for_room_DCD_industrial_high_hazard = egress_capacity_factor_analysis_for_doors(10)
#             out.print_md('**As per DCD- Door Egress Width Required, for the following Rooms, for Board and Care Building are as per follows:**')            
#             output_for_door_egress_comparision_DCD_industrial_high_hazard = output_statement_for_egress_comparision(egress_capacity_required_for_room_DCD_industrial_high_hazard)

#         elif userInputcategory_door_exit_building_without_sprinkler_chk == '04.Day Care':
#             egress_capacity_required_for_room_DCD_day_care = egress_capacity_factor_analysis_for_doors(5.6)
#             out.print_md('**As per DCD- Door Egress Width Required, for the following Rooms, for Day Care Building are as per follows:**')            
#             output_for_door_egress_comparision_DCD_day_care = output_statement_for_egress_comparision(egress_capacity_required_for_room_DCD_day_care)           
            
#         else:
#             pass 

    # Sprinklered
    
    elif(userInputcategory_building_sprinkler_chk) == '01.Sprinklered':
        out.print_md("No Data found for Sprinklered Building, as per DCD Code.")
        
    else:
        pass  

######################################################################################################################
else:
    pass

#####################################################################################################################